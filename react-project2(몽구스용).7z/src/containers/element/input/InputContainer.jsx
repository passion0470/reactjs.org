import React, { Component, Fragment } from 'react';
import PropTypes from 'prop-types'
// import Input from 'components/element/input/Input'

class InputContainer extends Component {
    constructor (props) {
        super(props)
        this.state = { value: props.value, isValid: this.handlePattenCheck(props.value) }
    }

    // 프로퍼티가 변경 상황
    componentWillReceiveProps(nextProps) {
        this.setState({ value: nextProps.value, isValid: this.handlePattenCheck(nextProps.value) })
    }

    handlePattenCheck(val) {
        // 패턴 체크
        const { pattern } = this.props
        return pattern === null ? true : pattern.test(val)
    }
    handleInputChange(e) {
        // 초기화
        const { filter, name } = this.props
        let nextValue = e.target.value
        // 입력값 필터
        if (filter !== null) nextValue = nextValue.replace(filter, '')
        // 입력값 패턴 체크
        const nextIsValid = this.handlePattenCheck(nextValue)
        // 상태변경
        this.setState({ value: nextValue, isValid: nextIsValid })
        // 이벤트를 실행 (props에 있는 onChange의 핸들링을 그대로 사용)
        // target은 해당 this고, value는 해당 value를 이걸로 바꿔준다. 나머지도 마찬가지다.
        // 나머지는 책 찾아보고 이해해보자.
        // console.log(this, nextValue, nextIsValid, name)
        if(this.props.onChange) this.props.onChange({ target: this, value: nextValue, name: name, isValid: nextIsValid })
    }
    renderStatus() {
        const { value, isValid } = this.state
        return isValid ? 'OK!' : value !== '' && 'NG!'
    }

    render() {
        const { name, placeholder } = this.props, { value } = this.state
        return (
            <Fragment>
                <input type="text" name={name} placeholder={placeholder} value={value} onChange={e => this.handleInputChange(e)} />
                {this.renderStatus()}
            </Fragment>
        );
    }
}

// 프로퍼티의 자료형 정의
InputContainer.propTypes = {
    name: PropTypes.string.isRequired,
    filter: PropTypes.object,
    pattern: PropTypes.object,
    value: PropTypes.string,
    placeholder: PropTypes.string,
    onChange: PropTypes.func
}
  // 프로퍼티의 초깃값 정의
InputContainer.defaultProps = {
    filter: null, pattern: null, value: '', placeholder: '', onChange: null
}

export default InputContainer;

// 필터는 지우고, 패턴은 그 규정을 지켜서, 상황을 반환하는 것?
