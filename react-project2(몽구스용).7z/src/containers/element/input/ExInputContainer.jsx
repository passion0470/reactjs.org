import React, { Component } from 'react';
import PropTypes from 'prop-types'

class ExInputContainer extends Component {
    constructor (props) {
        super(props)
        this.state = { value: props.value, isOK: this.handleCheckValue(props.value) }
    }

    componentWillReceiveProps (nextProps) {
        this.setState({ value: nextProps.value, isOK: this.handleCheckValue(nextProps.value) })
    }

    handleCheckValue (s) {
        if (this.props.pattern === null) return true
        return this.props.pattern.test(s)
    }
    handleInputChange (e) {
        const { value } = e.target, { filter, onChange, name } = this.props
        let nextValue = value

        if (filter !== null) nextValue = nextValue.replace(filter, '')
        const newIsOK = this.handleCheckValue(nextValue)

        this.setState({ value: nextValue, isOK: newIsOK })
        // 이벤트를 실행합니다. --- (※4)
        if (onChange) onChange({ target: this, value: nextValue, isOK: newIsOK, name: name })
    }
    renderStatusMessage () {
        const so = { margin: '8px', padding: '8px', color: 'white' }
        let msg = null
        if (this.state.isOK) { so.backgroundColor = 'green'; msg = <span style={so}>OK</span>
        } else {
          if (this.state.value !== '') { so.backgroundColor = 'red'; msg = <span style={so}>NG</span> }
        }
        return msg
    }

    render () {
        return (
        <div>
            <label>{this.props.label}: <br />
                <input type='text' name={this.props.name} placeholder={this.props.placeholder} value={this.state.value} onChange={e => this.handleInputChange(e)} />
                {this.renderStatusMessage()}
            </label>
        </div>
        )
    }

}

// 프로퍼티의 자료형을 정의합니다. --- (※6)
ExInputContainer.propTypes = {
    name: PropTypes.string.isRequired,
    label: PropTypes.string.isRequired,
    filter: PropTypes.object,
    pattern: PropTypes.object,
    value: PropTypes.string,
    placeholder: PropTypes.string,
    onChange: PropTypes.func
}
// 프로퍼티의 초깃값을 정의합니다. --- (※7)
ExInputContainer.defaultProps = {
    filter: null,
    pattern: null,
    value: '',
    placeholder: '',
    onChange: null
}

export default ExInputContainer;