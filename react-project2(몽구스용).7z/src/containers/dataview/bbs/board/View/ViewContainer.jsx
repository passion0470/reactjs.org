import React, { Component } from 'react'
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
// import * as boardActions from 'stores/actions/board';
// import boardActions from 'stores/actions/board';
import { boardActions } from 'stores/actions/board';
import { withRouter } from 'react-router-dom';
import ViewPresenter from 'components/dataview/bbs/board/View/ViewPresenter'
import { downFile } from 'utils/input'

export class ViewContainer extends Component {
  constructor() {
    super();
    this.state = {}
  }

  componentDidMount() {
    // const params = new URLSearchParams(this.props.location.search)
    // params.get('post') && this.props.BoardActions.getPost(params.get('post'))
    const { location } = this.props
    const params = new URLSearchParams(location.search)
    this.props.BoardActions.getFiles(params.get('post'))
  }
  componentDidUpdate(prevProps, prevState) {
    const { location } = this.props
    const params = new URLSearchParams(location.search)
    if(params.get('post') && new URLSearchParams(prevProps.location.search).get('post') !== params.get('post')) {
      this.props.BoardActions.getFiles(params.get('post'))
    }

    // const prevParams = new URLSearchParams(prevProps.location.search)
    // // 과거를 기준으로 하는게 더정확할듯.. 
    // // if(nextParams.get('post') && Number(nextParams.get('post')) !== Number(this.props.post.get('_id')) && nextProps.post.get('_id') === this.props.post.get('_id')) {
    // if(prevParams.get('post') !== params.get('post')) {
    //     this.props.BoardActions.getPost(params.get('post'))
    //     // this.setState({ reply: { body: '', parent: -1, depth: 1 } })
    //     // this.props.BoardActions.getReplys(nextParams.get('post'))
    // }

  }
  componentWillReceiveProps(nextProps) {
    const nextParams = new URLSearchParams(nextProps.location.search)
    // 과거를 기준으로 하는게 더정확할듯.. 
    if(nextParams.get('post') && nextParams.get('post') !== this.props.post.get('_id') && nextProps.post.get('_id') === this.props.post.get('_id')) {
    // if(nextParams.get('post') && Number(nextParams.get('post'))) {
        this.props.BoardActions.getPost(nextParams.get('post'))
        // this.setState({ reply: { body: '', parent: -1, depth: 1 } })
        // this.props.BoardActions.getReplys(nextParams.get('post'))
    }
  }

  handleInitPost = () => {
    this.props.BoardActions.initPost()
  }
  handleToList = () => {
    const { id, location, history } = this.props
    const params = new URLSearchParams(location.search)
    const searchParams = { id: id, page: params.get('page') }
    params.get('svalue') && Object.assign(searchParams, {svalue: params.get('svalue')})
    params.get('stype') && Object.assign(searchParams, {stype: params.get('stype')})
    return history.push({
        pathname: location.pathname, search: "?" + new URLSearchParams(searchParams).toString()
    })
  } 
  handleDeletePost = () => {
    const { BoardActions, location } = this.props
    const params = new URLSearchParams(location.search)
    // BoardActions.deletePost({ postId: params.get('_id') }).then(() => {
    BoardActions.deletePost({ postId: params.get('post') }).then(() => {
      this.handleToList()
    })
  }
  handleReadFile = (id, name, type) => {
    const { BoardActions } = this.props
    BoardActions.getReadFiles(id).then(data => {
      downFile(data, name, type)
    })
  }
  handleDeleteFile = id => {
    const { BoardActions } = this.props
    BoardActions.deleteFile(id).then(data => {
      alert(data)
      // alert('delete succese')
    })
  }
  handleModifyFile = id => {
    // let filesArr = new FormData()
    // for (let i=0; i < files.length; i++) filesArr.append("files", files[i])
    // console.log(files !== [])
    // files !== [] && BoardActions.postFiles({files: filesArr, postId: data.id})
    // const { BoardActions } = this.props
    // BoardActions.putFile(id).then(data => {
    //   // alert(data)
    //   alert('update succese')
    // })
  }

  render() {
    const { post, files, onContainerBranch, onActiveEdit, replyContainer } = this.props
    return (
      <ViewPresenter post={post} files={files} replyContainer={replyContainer} onInitPost={this.handleInitPost} onToList={this.handleToList} onContainerBranch={onContainerBranch} onActiveEdit={onActiveEdit} onDeletePost={this.handleDeletePost} onReadFile={this.handleReadFile} onDeleteFile={this.handleDeleteFile} onModifyFile={this.handleModifyFile} />
    )
  }
}

export default connect(
  (state) => ({
    post: state.board.get('post'), 
    status: state.board.get('status'),
    files: state.board.get('files')
  }),
  (dispatch) => ({
    BoardActions: bindActionCreators(boardActions, dispatch)
  })
)(withRouter(ViewContainer));
