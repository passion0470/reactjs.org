import React, { Component } from 'react'
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
// import * as boardActions from 'stores/actions/board';
// import boardActions from 'stores/actions/board';
import { boardActions } from 'stores/actions/board';
import { withRouter } from 'react-router-dom';
import { ListContainer, ViewContainer, EditContainer, ReplyContainer } from './'

export class BoardContainer extends Component {
  constructor() {
    super();
    this.state = {}
  }

  handleActiveEdit = (e) => {
    const { name } = e.target
    // console.log(name)
    this.props.BoardActions.activeEdit(name)
  }
  handleToPost = postId => {
    const params = new URLSearchParams(this.props.location.search)
    const searchParams = { id: this.props.id, page: params.get('page') || 1, post: postId}
    params.get('svalue') && Object.assign(searchParams, {svalue: params.get('svalue')})
    params.get('stype') && Object.assign(searchParams, {stype: params.get('stype')})
    return this.props.location.pathname + "?" + new URLSearchParams(searchParams).toString()
  }
  handleContainerBranch = (key) => {
    return new URLSearchParams(this.props.location.search).get(key)
  }

  render() {
    const { id, titles, csizes, stypes } = this.props
    return (
      <div className="board-container">
        <ViewContainer 
          id={id} replyContainer={<ReplyContainer />} 
          onActiveEdit={this.handleActiveEdit} onContainerBranch={this.handleContainerBranch} />
        <ListContainer 
          id={id} titles={titles} csizes={csizes} stypes={stypes} 
          onActiveEdit={this.handleActiveEdit} onToPost={this.handleToPost} onContainerBranch={this.handleContainerBranch} />
        <EditContainer 
          id={id} onActiveEdit={this.handleActiveEdit} />
      </div>
    )
  }
}

export default connect(
  state => ({
    info: state.board.get('info'),
    posts: state.board.get('posts'), 
    post: state.board.get('post'), 
    replys: state.board.get('replys'), 
    status: state.board.get('status'), 
  }),
  dispatch => ({
    BoardActions: bindActionCreators(boardActions, dispatch)
  })
)(withRouter(BoardContainer));
