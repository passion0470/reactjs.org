import React, { Component } from 'react'
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
// import * as boardActions from 'stores/actions/board';
// import boardActions from 'stores/actions/board';
import { boardActions } from 'stores/actions/board';
import { withRouter } from 'react-router-dom';
import ReplyPresenter from 'components/dataview/bbs/board/Reply/ReplyPresenter'

export class ReplyContainer extends Component {
  constructor() {
    super();
    this.state = { 
      write: { id:null, body: '', parent: -1, depth: 1 },
      modify: { id:null, body: '', parent: -1, depth: 1 },
      status: { isEdit: 0, isIndex: -1 }
    };
    this.initialState = this.state
  }
  
  componentDidMount() {
    const params = new URLSearchParams(this.props.location.search)
    params.get('post') && this.props.BoardActions.getReplys(params.get('post'))
  }

  componentDidUpdate(prevProps, prevState) {
    // console.log(prevState)
    const { status } = this.state, { replys } = this.props
    const replysGet = (key) => replys.getIn([status.isIndex, key])
    if(prevState.status.isEdit !== status.isEdit) {
      status.isEdit !== 0 && this.setState({modify: {id: replysGet('_id'), body: replysGet('body'), parent: replysGet('parent'), depth: replysGet('depth')}})
    }
  }
   

  handleInputChange = (e) => {
    const { value, name } = e.target;
    // console.log(value, name)
    const nameSep = name.split('.')
    return name.includes('.') ? this.setState({[nameSep[0]]: {...this.state[nameSep[0]], [[nameSep[1]]]: value }}) : this.setState({ [name]: value })
    // this.setState({edit: {...this.state.edit, [name]: value }})
    // this.setState({ [name]: value })
  }
  handleModifyCheck = (replyId, replyIndex) => {
    // console.log(replyId, replyIndex)
    this.setState({status: {...this.state.status, isEdit: replyId, isIndex: replyIndex }})
    // 모피디 체크와 별개로, 쓰기 쓸수도 있다. 즉 따로 분리해야한다.
  }
  handleSubmit = (e, replyId) => {
    if(e) e.preventDefault(e)
    replyId ? this.handlePatchReply(replyId) : this.handlePostReply()
  }
  handlePostReply = () => {
    const params = new URLSearchParams(this.props.location.search)
    this.props.BoardActions.postReply({reply: this.state.write, postId: params.get('post')}).then(() => {
        this.props.BoardActions.getReplys(params.get('post'))
        this.setState(this.initialState)
    })
  }
  handlePatchReply = (replyId) => {
    // console.log(replyId)
    const params = new URLSearchParams(this.props.location.search)
    this.props.BoardActions.patchReply({ reply: this.state.modify, replyId: replyId }).then(() => {
      this.props.BoardActions.getReplys(params.get('post'))
      this.setState(this.initialState)
    })
  }
  handleInitReplys = () => {
    this.props.BoardActions.initReplys()
  }

  render() {
    const { replys } = this.props, { modify, write, status } = this.state
    return (
      <ReplyPresenter replys={replys} modify={modify} write={write} status={status} onInputChange={this.handleInputChange} onSubmit={this.handleSubmit} onModifyCheck={this.handleModifyCheck} onInitReplys={this.handleInitReplys} />
    )
  }
}

export default connect(
  (state) => ({
    post: state.board.get('post'), 
    replys: state.board.get('replys'), 
    status: state.board.get('status'), 
  }),
  (dispatch) => ({
    BoardActions: bindActionCreators(boardActions, dispatch)
  })
)(withRouter(ReplyContainer));


// 리플리도 리플리가 1 이상인 경우만 API호출로 하자.. 그 이하는 안하는걸로, 그리고 서버에서, 리스트라던지, 포스트라던지, 코멘트 갯수만 보내주는걸로 하자..