import React, { Component } from 'react'
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
// import * as boardActions from 'stores/actions/board';
// import boardActions from 'stores/actions/board';
import { boardActions } from 'stores/actions/board';
import { withRouter } from 'react-router-dom';
import EditPresenter from 'components/dataview/bbs/board/Edit/EditPresenter'
// import { toEmptyValue, toFormData } from 'utils/input'

export class EditContainer extends Component {
  constructor() {
    super();
    this.state = {
        post: { id:null, title: '', body: '', tags: [] },
        // files: { file1: '', file2: '', file3: '' }
        files: []
    };
    this.initialState = this.state
  }

  componentDidMount() {
    // const { post } = new URLSearchParams(this.props.location.search)
    // Promise.resolve(this.props.BoardActions.initPost()).then(() => {
    //   post && this.props.BoardActions.getPost(post)
    // })
  }

  componentDidUpdate(prevProps) {
    const { status, post } = this.props
    if(prevProps.status.get('isEdit') !== status.get('isEdit')) {
      ['post.write', 'reply.write'].includes(status.get('isEtype')) && this.setState(this.initialState)
      status.get('isEtype') === 'post.modify' && this.setState({post: {id: post.get('_id'), title: post.get('title'), body: post.get('body'), tags: post.get('tags')}})
      // status.get('isEtype') === 'reply.modify' && this.setState({reply: {id: post.get('_id'), body: post.get('body')} })
    }
  }
   
  // handleChangeInput = (e) => {
  //   const { value, name } = e.target
  //   this.props.BoardActions.changeInput({name, value})
  // }
  handleChangeInput = (e) => {
    const { value, name } = e.target, nameSep = name.split('.')
    console.log(value, name)
    name.includes('.') 
      ? this.setState({[nameSep[0]]: {...this.state[nameSep[0]], [[nameSep[1]]]: value }}) 
      : this.setState({ [name]: value })
    // 점이 두개인지, 3개인지 체크.. 그리고 이걸 공통 활용 방향도 고민
  }

  // handleChange({ target }) {
  //   this.setState({
  //     [target.name]: target.value,
  //   })
  // }

  handleChangeFile = e => {
    // const { name, files } = e.target, useName = name.split('.')
    // console.log(files[0])
    // name.includes('.') 
    //     ? this.setState({[useName[0]]: {...this.state[useName[0]], [[useName[1]]]: files[0] }}, () => { console.log(this.state.files) }) 
    //       : this.setState({ [name]: files[0] }, () => { console.log(this.state.files) })

    // const { name, files } = e.target
    // console.log(files[0])
    // console.log(e.target)
    // this.setState({[name]: [...this.state[name], {[index]: files[0]}] }, () => { console.log(this.state.files) }) 
    // this.setState({[name]: this.state.files[index].concat(files[0]) }, () => { console.log(this.state.files) }) 

    // const { name, files } = e.target, useName = name.split('[')
    // console.log(files[0])
    // name.includes('[') 
    //     ? this.setState({[useName[0]]: {...this.state[useName[0]], [useName[1].replace("]", "")]: files[0]} }, () => { console.log(this.state.files) }) 
    //     : this.setState({ [name]: files[0] }, () => { console.log(this.state.files) })

    const { name, files } = e.target
    console.log(files)
    console.log(e.target)
    this.setState({[name]: files}, () => console.log(this.state.files)) 
  }
  handleSubmit = (e) => {
    if(e) e.preventDefault(e)
    // e.preventDefault()
    const { status } = this.props
    status.get('isEtype') === 'post.write' && this.handleInsertPost()
    status.get('isEtype') === 'post.modify' && this.handlePatchPost()
  }
  handlePatchPost = () => {
    const { BoardActions, location, history, id } = this.props, { post } = this.state
    const params = new URLSearchParams(location.search)
    BoardActions.patchPost({ post: post, id: id, postId: post.id }).then((response) => { 
      BoardActions.getPosts({id: id, page: params.get('page') || 1})
      const searchParams = { id: id, page: params.get('page') || 1, post: response.payload.data.id}
      history.push({
          pathname: location.pathname, search: "?" + new URLSearchParams(searchParams).toString()
      })    
    })
  }
  handleInsertPost = () => {
    // 기존 포스트 빈값 만들기 알아두기
    const { location, id, BoardActions, history } = this.props, { post, files } = this.state
    const params = new URLSearchParams(location.search)
    // console.log(toEmptyValue(files))
    // toEmptyValue(files) && BoardActions.postFiles({files: toFormData(files), postId: id})
    BoardActions.postInsert(id, post).then(data => { 
      // let file = new FormData()
      // file.append('file', files.file1)
      // files.file1 && BoardActions.postFile({file: file, postId: data.id})

      let filesArr = new FormData()
      for (let i=0; i < files.length; i++) filesArr.append("files", files[i])
      console.log(files !== [])
      files !== [] && BoardActions.postFiles({files: filesArr, postId: data._id})
      BoardActions.getPosts({id: id, page: params.get('page') || 1})
      const searchParams = { id: id, page: params.get('page') || 1, post: data._id}
      history.push({
          pathname: location.pathname, search: "?" + new URLSearchParams(searchParams).toString()
      })
    })
  }

  postFiles

  render() {
    const { status, onActiveEdit } = this.props, { post } = this.state
    return (
      <EditPresenter status={status} post={post} onChangeInput={this.handleChangeInput} onSubmit={this.handleSubmit} onActiveEdit={onActiveEdit} onChangeFile={this.handleChangeFile} />
    )
  }
}

export default connect(
  (state) => ({
    post: state.board.get('post'), 
    replay: state.board.get('replay'), 
    status: state.board.get('status'),
  }),
  (dispatch) => ({
    BoardActions: bindActionCreators(boardActions, dispatch)
  })
)(withRouter(EditContainer));
