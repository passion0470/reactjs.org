import React, { Component } from 'react'
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
// import * as boardActions from 'stores/actions/board';
// import boardActions from 'stores/actions/board';
import { boardActions } from 'stores/actions/board';
import { withRouter } from 'react-router-dom';
import ListPresenter from 'components/dataview/bbs/board/List/ListPresenter'

export class ListContainer extends Component {

  handleGetPosts = ({ id, page, stype, svalue }) => {
    const params = svalue ? { id, page, stype, svalue } : { id, page }
    return this.props.BoardActions.getPosts(params)
  }

  render() {
    const { id, titles, csizes, stypes, posts, status, onActiveEdit, onToPost, onContainerBranch } = this.props
    const { handleGetPosts } = this
    return (
      <ListPresenter
        id={id} titles={titles} csizes={csizes} stypes={stypes} posts={posts} status={status} 
        onGetPosts={handleGetPosts} onActiveEdit={onActiveEdit} onToPost={onToPost} onContainerBranch={onContainerBranch} />
    )
  }
}

export default connect(
    (state) => ({
      info: state.board.get('info'),
      posts: state.board.get('posts'), 
      status: state.board.get('status')
    }),
    (dispatch) => ({
      BoardActions: bindActionCreators(boardActions, dispatch)
    })
)(withRouter(ListContainer));
  