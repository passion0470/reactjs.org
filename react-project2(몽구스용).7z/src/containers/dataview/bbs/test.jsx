import React, { Component } from 'react';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import * as boardActions from 'stores/actions/board';
import { withRouter } from 'react-router-dom';
import Board from 'components/dataview/bbs/board/Board'
import { SearchParams } from 'utils/params'


class BoardContainer extends Component {

    constructor(props) {
        super(props);
        this.state = { 
            edit: { title: '', body: '', tags: [] }, reply: { body: '', parent: -1, depth: 1 }
        };
        this.sParams = new SearchParams(props)
    }

    componentDidMount() {
        this.handleGetBoard()
        // this.handleGetPost(this.handleParamBranch('post'))
    } 

    componentWillReceiveProps(nextProps) {
        const params = new URLSearchParams(nextProps.location.search)
        if (params.get('post') && Number(params.get('post')) !== Number(this.props.post.get('_id'))) {
            this.props.BoardActions.getPost(params.get('post'))
            this.setState({ reply: { body: '', parent: -1, depth: 1 } })
            this.props.BoardActions.getReplys(Number(params.get('post')))
        }
    }

    handleGetBoard = () => {
        return this.props.BoardActions.getBoard()
    }

    handleGetPosts = ({id, page, type, value}) => {
        const params = value ? {id, page, type, value} : {id, page}
        return this.props.BoardActions.getPosts(params)
    }

    handleGetPost = (id) => {
        return this.props.BoardActions.getPost(id)
    }

    handlePostPathParams = (postId) => {
        const queryString = { id: this.props.id, page: this.sParams.get('page') || 1, post: postId}
        return this.props.location.pathname + "?" + new URLSearchParams(queryString).toString()
    }

    handleParamBranch = (key) => {
        return this.sParams.get(key)
    }

    handlePostEdit = (val) => {
        console.log(val)
        Promise.resolve(this.props.BoardActions.changeEtype(val)).then(() => {
            return this.props.BoardActions.activeEdit()
        })
    }

    // handleEditChange = ({name, value}) => {
    //     this.setState({edit: {...this.state.edit, [name]: value }}, ()=> console.log(this.state.user))
    // }

    handleEditChange = (e) => {
        const { value, name } = e.target;
        console.log(value, name)
        const nameSep = name.split('.')
        return name.includes('.') ? this.setState({[nameSep[0]]: {...this.state[nameSep[0]], [[nameSep[1]]]: value }}) : this.setState({ [name]: value })
        // this.setState({edit: {...this.state.edit, [name]: value }})
    }

    handlePostInsert = () => {
        // 기존 포스트 빈값 만들기 알아두기
        this.props.BoardActions.postInsert(this.props.id, this.state.edit).then((response) => { 
            this.props.BoardActions.getPosts({id: this.props.id, page: this.sParams.get('page') || 1})
            const queryString = { id: this.props.id, page: this.sParams.get('page') || 1, post: response.payload.data.id}
            this.props.history.push({
                pathname: this.props.location.pathname, search: "?" + new URLSearchParams(queryString).toString()
            })
        })
    }

    handlePostUpdate = () => {
        this.props.BoardActions.patchPost({ post:this.state.edit, id:this.props.id, postId: Number(this.sParams.get('post'))})
    }

    handleInitPost = () => {
        this.props.BoardActions.initPost()
    }
 
    handleListMove = () => {
        // console.log(params.get('post'))
        // delete params.get('post')
        // 키값 삭제 방법 알아보기
        const queryString = { id:this.props.id, page: this.sParams.get('page') }
        return this.props.history.push({
            pathname: this.props.location.pathname, search: "?" + new URLSearchParams(queryString).toString()
        })
    }

    handlePostReply = () => {
        this.props.BoardActions.postReply({reply: this.state.reply, postId: Number(this.sParams.get('post'))}).then(() => {
            this.props.BoardActions.getReplys(Number(this.sParams.get('post')))
        })
    }


    // 포스트뷰나, 리스트등으로 보드.jsx를 여기다 가져오는게 맞을듯. 단, 조건애니 처리는 그 해당 래퍼로 들어가서 그 안에서 처리하는게 좋을듯.
    // 혹은 에디터컨테이너, 뷰컨테이너, 리플라이컨테이너, 리스트컨테이너등 모두 분류한뒤, 보드 컨테이너에서 합치는 방식도 고민
    render() {
        const { id, action, titles, cols, posts, post, status, searchType, replys, BoardActions, ...rest } = this.props
        const { edit, reply } = this.state
        return (
            <Board 
                id={id} titles={titles} cols={cols} action={action} totalPage={13} searchType={searchType} {...rest} 
                onGetPosts={this.handleGetPosts} onGetPost={this.handleGetPost} posts={posts} post={post}
                onPostPathParams={this.handlePostPathParams}
                onParamBranch={this.handleParamBranch} 
                status={status} edit={edit} 
                onEditChange={this.handleEditChange}
                onPostInsert={this.handlePostInsert}
                onListMove={this.handleListMove}
                onInitPost={this.handleInitPost}
                onPostReply={this.handlePostReply}
                onPostEdit={this.handlePostEdit}
                reply={reply} replys={replys}
                onPostUpdate={this.handlePostUpdate}
                onChangePost={BoardActions.changePost}
            />
        );
    }
}


// 재설계 기준
// board/list/ListWarpContainer, board/view/ViewWrapContainer, board/edit/EditWrapContainer, board/reply/ReplyWrapContainer
// 예를 들어 즐겨찾기라던지, 그런 요소별로, 컨테이너가 들어가는게, 맞다고 본다. 즉. 지금은 잘못 설계함. 너무 한개로만 하려다보니. 잘못 설계했다.
// 통합: BoardContainer에 위에 해당하는 기준을 모아주고, 여기서 통합형 로직을 다시 한번 설정하는 걸로 한다.
// 컨테이너 기준은 부품별로도 되지만, 화면이 바뀌는 부분은 무조건 컨테이너로 따로 뽑는게 좋다.
// 그리고 불필요하게 너무 쪼개진 말자. 필요에 의해서 쪼개자. 정도를 걷자는것.
// 또한 라우터 트랜지션도 고려해야한다.

export default connect(
    (state) => ({
        board: state.board.get('board'),
        posts: state.board.get('posts'), 
        post: state.board.get('post'), 
        replys: state.board.get('replys'), 
        status: state.board.get('status'), 
    }),
    (dispatch) => ({
        BoardActions: bindActionCreators(boardActions, dispatch)
    })
)(withRouter(BoardContainer));