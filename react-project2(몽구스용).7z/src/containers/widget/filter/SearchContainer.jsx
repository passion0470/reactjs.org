import React, { Component } from 'react';
import Search from 'components/widget/filter/Search'
import { withRouter } from "react-router-dom";

class SearchContainer extends Component {

    constructor(props) {
        super(props);
        this.state = { stype: props.stypes ? props.stypes[0].toLowerCase() : '', svalue: '' };
    }

    componentDidUpdate(prevProps) {
        const params = (props, key) => new URLSearchParams(props.location.search).get(key)
        if (params(this.props, 'svalue') && params(this.props, 'svalue') !== params(prevProps, 'svalue')) {
            Promise.resolve(this.setState({ svalue: params(this.props, 'svalue') })).then(() => {
                this.handleSubmit()
            })
        } else if (params(this.props, 'stype') && params(this.props, 'stype') !== params(prevProps, 'stype') && params(this.props, 'svalue') === params(prevProps, 'svalue')) {
            Promise.resolve(this.setState({ stype: params(this.props, 'stype') })).then(() => {
                this.handleSubmit()
            })
        }
    }

    // 검색의 경우, 타입이 있는 경우와 없는 경우, 그리고 프론트에서만 서치, 백에서 서치. 이렇게 나뉜다. (나누기 어려우면, 서버서치, state서치)
    // 일단은 타입이 있는 경우와 없는 경우부터 해보자.

    // 프론트 서치는 타입이 없는 걸 먼저 생각하고, 그 후 타입이 있는걸 생각해보자.
    // ServerDataSearch.jsx / StateDataSerach.jsx, 스테이트일 경우, 컨테이너가 하나 더 필요할수도.. 해당 영역만 서치한다란 느낌으로..
    // ServerSearch.jsx / ClientSerach.jsx, 클라이언트 서치는 구조가 좀 다를수도, 일단 따로 만들고, 합칠수 있으면 그때 고민.

    handleValueChange = (e) => {
        const { value, name } = e.target;
        console.log(value, name)
        this.setState({ [name]: value })
    }

    handleSubmit = (e) => {
        if(e) e.preventDefault()
        const { stype, svalue } = this.state, { id } = this.props
        this.props.onGetPosts({ id: id, stype: stype, svalue: svalue }).then(() => {
            const queryString = { id: id, stype: stype, svalue: svalue }
            this.props.history.push({
                pathname: this.props.location.pathname, search: "?" + new URLSearchParams(queryString).toString()
            })
        })
    }

    handleReset = () => {
        const { id } = this.props
        this.setState({ svalue:'' })
        this.props.onGetPosts({ id: id }).then(() => {
            const queryString = { id: id }
            this.props.history.push({
                pathname: this.props.location.pathname, search: "?" + new URLSearchParams(queryString).toString()
            })
        })
    }
    
    // 1.다른 페이지로 넘어갔을때 문제, 토탈페이지 재대로 왔는데, 그 값을 못읽는 부분,
    // 토탈값은 기본적으로 보드 게시판에서 처리하되, 검색은 쿼리스트링으로 한번 해보자는 부분?
    // 생각을 해보자.. 일단 
    // 일단은 토탈페이지가 바뀐걸, 페이지네이터에 전달하고, 그걸 자동으로 읽어서.. 바뀌면 다시 불러오기
    // 페이지네이션, 현재페이지 액티브 클래스 처리 부분
    // 궁극적으로 페이지게이터는 따로 리덕스 해두는게 좋을까., 생각해보니, 리스트의 음.. 아니.. 각각 리미트가 다를수 있긴하지만, 물론.. 음.. 리미트를 하..

    // 기본은 1페이지를 가져오는데, 2페이지를 넘어갈떄, 페이지네이션 값에서 처리할테니.. 가능할수도
    // 2. 타입 유무 분기문 처리
    // 3. 페이지네이션이나 포스트액션에, 파라미터 처리 부분

    render() {
        const { stypes } = this.props, { svalue } = this.state
        return (
            <Search stypes={stypes} svalue={svalue} onValueChange={this.handleValueChange} onSubmit={this.handleSubmit} onReset={this.handleReset} />
        );
    }
}

export default withRouter(SearchContainer);