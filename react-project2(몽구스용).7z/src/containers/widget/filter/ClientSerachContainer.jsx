import React, { Component } from 'react';
import ClientSerachPresenter from 'components/widget/filter/ClientSerachPresenter'

class ClientSerachContainer extends Component {
    constructor(props) {
        super(props);
        this.state = { svalue: '' };
    }

    handleValueChange = (e) => {
        const { value, name } = e.target;
        console.log(value, name)
        this.setState({ [name]: value })
    }

    render() {
        return (
            <ClientSerachPresenter post={this.props.post} onChange={this.handleValueChange} children={this.props.children}/>
        );
    }
}

export default ClientSerachContainer;

// 가장 좋은 방법이 현재로선, 해당 페이지에 상태값을 넣어 처리하거나, 클라이언트서치의 뷰 영역을 따로 만든다. 그리고 그 뷰에 해당 값이 적용되는 자식 컴포넌트로 삽입

// 아니면 이걸 좀 더 크게 만들어서, 이 클라이언트 서치 컨테이너로, 자식 컴포넌트로 삽입?