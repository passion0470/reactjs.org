import React, { Component } from 'react';
import PropTypes from 'prop-types';
import Tabs from 'components/widget/tab/Tabs'

class TabsContainer extends Component {
    static propTypes = {
        children: PropTypes.instanceOf(Array).isRequired
    }

    constructor(props) {
        super(props);
        this.state = { 
            activeTab: this.props.children[0].props.label,
        };
    }

    onClickTabItem = (tab) => {
        this.setState({ activeTab: tab }, () => console.log(tab));
    }
    
    render() {
        const { children, ...rest } = this.props
        return (
            <Tabs activeTab={this.state.activeTab} onClickTabItem={this.onClickTabItem} children={this.props.children} {...rest}/>
        );
    }
}

export default TabsContainer;