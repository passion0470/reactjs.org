import React, { Component } from 'react';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
// import * as modalActions from 'stores/actions/modal';
import { modalActions } from 'stores/actions/modal';
import ModalPresenter from 'components/widget/modal/ModalPresenter'

class ModalContainer extends Component {
    handleModalShow = (val) => {
        this.props.ModalActions.modalShow(val);
    }

    render() {
        // const { id, status, onModalShow, title, body, footer, overall } = this.props
        const { id, status, ...rest } = this.props
        return (
            // <Modal id={id} status={status} onModalShow={onModalShow} title={title} body={body} footer={footer} overall={overall} />
            <ModalPresenter id={id} status={status} onModalShow={this.handleModalShow} {...rest} />
        );
    }
}

// export default ModalContainer
export default connect(
    (state) => ({
        status: state.modal.get('status'),
    }),
    (dispatch) => ({
        ModalActions: bindActionCreators(modalActions, dispatch)
    })
)(ModalContainer);