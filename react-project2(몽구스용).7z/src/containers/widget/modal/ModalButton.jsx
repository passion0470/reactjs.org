import React, { Component } from 'react';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
// import * as modalActions from 'stores/actions/modal';
import { modalActions } from 'stores/actions/modal';
import ButtonPresenter from 'components/element/button/ButtonPresenter'

class ModalButton extends Component {
    handleModalShow = (id) => {
        this.props.ModalActions.modalShow(id);
        console.log(this.props.ModalActions.modalShow(id))
    }

    render() {
        const { id, children, ...rest } = this.props
        return (
            <ButtonPresenter onClick={() => this.handleModalShow(id)} children={children} {...rest} />
        );
    }
}

// 아무래도, 버튼 프리젠터만 활용해서, 페이지에서, 해당 액션클릭함수를 가져와서 처리하는게 좋을 것 같다. 일단은 더 고민해보자.
// 쩃든, 버튼프리젠터만으로 만든건 잘한거다. 공통으로 컴포넌트 활용성을 높여야한다. 일단은 프리젠터만 활용해서 이렇게 하는것도 나쁘지 않을수 있다..

export default connect(null, 
    (dispatch) => ({ 
        ModalActions: bindActionCreators(modalActions, dispatch) 
    })
)(ModalButton);

// 모달버튼은 여기에 따로 두기보다, 엘리먼트에 둬서, 페이지네이터처럼 완전한 공통화로 활용할수 있게 하자..
// 즉 버튼 컨테이너를 만들자. 이벤트나 그런걸, props로 받아서 처리하는걸로 하고. ...restdata와 함께. 혹은 actionData


// 회원가입 메시지, 인풋이나 폼, 클라이언트 서치