import React, { Component } from 'react';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import * as navActions from 'stores/actions/navigate';
import Toolbar from 'components/widget/toolbar/Toolbar'
import AuthService from 'services/authService'
import { withRouter } from "react-router-dom";

class ToolbarContainer extends Component {
    constructor(){
        super();
        this.state = { };
        this.authService = new AuthService();
    }

    componentDidMount() {
        console.log(this.authService.signedIn())
    }

    handleSignOut = () => {
        new AuthService().signOut().then(() => {
            this.props.history.push('/user/signin')
        })
    }

    render() {
        return (
            <Toolbar list={this.props.list} onSignedIn={this.authService.signedIn()} onSignOut={this.handleSignOut}/>
        );
    }
}

export default connect(
    (state) => ({
        list: state.navigate.getIn(['toolNav', 'list']),
    }),
    (dispatch) => ({
        NavActions: bindActionCreators(navActions, dispatch)
    })
)(withRouter(ToolbarContainer));



