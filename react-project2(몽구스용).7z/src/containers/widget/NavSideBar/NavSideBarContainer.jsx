import React, { Component } from 'react';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import * as navActions from 'stores/actions/navigate';
import NavSideBarPresenter from 'components/widget/NavSideBar/NavSideBarPresenter'

class NavbarContainer extends Component {
    constructor(){
        super()
        this.state = { }
    }

    componentDidMount() {
    }

    handleShowControl = (index) => {
        this.props.NavActions.changeShow({index, depth: 2})
    }
    handleEnter(el) {
        el.style.height = el.scrollHeight + 'px'
    }
    handleExit(el) {
        // return el.style.height = '0px'
        el.style.height = (el.scrollHeight - el.scrollHeight) + 'px'
    }

    render() {
        const { id, status, list } = this.props
        return (
            <NavSideBarPresenter id={id} status={status} list={list} onShowControl={this.handleShowControl} onEnter={this.handleEnter} onExit={this.handleExit} />
        );
    }
}

export default connect(
    (state) => ({
        list: state.navigate.getIn(['globalNav', 'list']),
        status: state.navigate.getIn(['globalNav', 'status']),
    }),
    (dispatch) => ({
        NavActions: bindActionCreators(navActions, dispatch)
    })
)(NavbarContainer);

