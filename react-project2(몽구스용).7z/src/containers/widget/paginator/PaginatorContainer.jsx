import React, { Component } from 'react';
import { withRouter } from "react-router-dom";
import Paginator from 'components/widget/paginator/Paginator'

class PaginatorContainer extends Component {
    constructor(props) {
        super(props);
        this.state = { 
            row: { total:null, limit:10 }, 
            page: { total:1, current:1, limit: 5, list: [] }
        }
    }

    // row 리미트가 필요한 경우, 각각 props로 받은후 처리하면 될듯.. 즉 보드나, 그리드, 거기서 하나로 받고, 각각 삽입해 처리 등.
    // 일단은 이렇게 하고, 나머지 처리는, 좀 더 고민해보자. 좀 더 깔끔하게 처리되야한다. 에러도 살짝 있다. 특히 서치후에
    // post 라우트는 기본적으로 페이징 이동시 없어지는게 맞다.

    componentDidMount() {
        this._isMounted = true;
        const params = new URLSearchParams(this.props.location.search)
        this.handleCurrentPage(params.get('page') || 1);
    }
    componentWillUnmount() {
        this._isMounted = false;
    }
    componentDidUpdate(prevProps, prevState) {
        const paramPage = (props) => Number(new URLSearchParams(props.location.search).get('page'))
        const statePage = (statePage) => statePage.page.current
        if (paramPage(this.props) !== paramPage(prevProps) && paramPage(prevProps) === statePage(this.state)) 
            this.handleCurrentPage(paramPage(this.props))
        else if (statePage(this.state) !== statePage(prevState)) 
            this.handlePathParams(statePage(this.state)) 
        if (prevProps.totalPage && prevProps.totalPage !== this.props.totalPage)
            this.handlePageList(paramPage(this.props), this.props.totalPage)
    }
    // 검색 두번 불러오고, 뷰 불러올떄 심각하게 많이 불러옴.. 특히 뷰 부분은 개선이 확실히 필요 

    handlePathParams = (currentPage) => {
        // 라우트 값 가져오기
        const params = new URLSearchParams(this.props.location.search)
        const searchParams = { id: this.props.id, page: currentPage || 1 }
        params.get('svalue') && Object.assign(searchParams, {svalue: params.get('svalue')});
        params.get('stype') && Object.assign(searchParams, {stype: params.get('stype')});
        this.props.history.push({
            pathname: this.props.location.pathname,
            search: "?" + new URLSearchParams(searchParams).toString()
        })
    }
    handlePageList(currentPage, totalPage) {
        // 1. 초기값 정의
        // 토탈페이지 정의 및 현재값 기준으로 앞뒤 값 정의하는 하프리미트 정의
        // totalPage = 15
        const { page } = this.state
        const halfLimit = Math.floor(page.limit/2)
        // 현재값 기준으로 블록의 시작과 끝값 정의
        let paging = {}
        paging.start = currentPage - halfLimit 
        paging.end = paging.start + page.limit

        // 2. 조건 체크
        // 현재 페이지 값 기준으로 시작값이 최초값이 하프리미트를 뺼때 0보다 작거나, 최대값이 토탈값을 넘어설 경우 처리
        if(paging.start - halfLimit < 0) {
            paging.start = 1
            paging.end = paging.start + page.limit
        } else if(paging.end > totalPage) {
            paging.end = (totalPage+1)
            paging.start = paging.end - page.limit
        }
        
        // 최초 페이지 토탈이 페이지 리미트보다 작을 경우 처리
        if(totalPage < page.limit) {
            paging.start = 1
            paging.end = Number(paging.start) + Number(totalPage === 0 ? 1 : totalPage)
        }

        // 3. 시작과 끝값으로 범위를 구한다.
        this.handlePageScope(paging.start, paging.end)
    }
    handlePageScope(startPage, endPage) {
        let pageScope = []
        for(let i=startPage; i < endPage; i++) pageScope.push(i) 
        console.log(pageScope)
        this.setState({page: {...this.state.page, list: pageScope }})
    }
    handleSkipPrevPage = () => {
        // 처음과 끝 값 구하기
        const { page } = this.state
        let prevSkip = {}
        prevSkip.end = page.list[0]
        prevSkip.start = prevSkip.end - page.limit

        // 1보다 작은 경우 조건 처리
        if(prevSkip.start < 1) {
            prevSkip.start = 1
            prevSkip.end = prevSkip.start + page.limit
        }

        // 현재 위치값 적용
        const halfLimit = Math.floor(page.limit/2)
        if((prevSkip.end-1) > page.limit) this.handleCurrentPage(prevSkip.start + halfLimit)
        else this.handleCurrentPage(1)
    }
    handleSkipNextPage = () => {
        let nextSkip = {}
        const { page } = this.state, { totalPage } = this.props
        // 처음값과 끝 값 구하기
        nextSkip.start = page.list[page.list.length-1]+1
        nextSkip.end = (nextSkip.start) + page.limit

        // 토탈보다 클 경우 조건 처리
        if(nextSkip.end > totalPage) {
            nextSkip.end = (totalPage+1)
            nextSkip.start = nextSkip.end - page.limit
        }

        // 현재 위치값 적용
        const halfLimit = Math.floor(page.limit/2)
        if(nextSkip.end < totalPage) this.handleCurrentPage(nextSkip.start + halfLimit)
        else this.handleCurrentPage(totalPage)
    }
    handleIncrementPage = () => {
        const { current } = this.state.page, { totalPage } = this.props
        current < totalPage && this.handleCurrentPage(current+1)
    }
    handleDecrementPage = () => {
        const { current } = this.state.page
        current > 1 && this.handleCurrentPage(current-1)
    }
    handleCurrentPage = (currentPage) => {
        const params = new URLSearchParams(this.props.location.search)
        const searchParams = { id: this.props.id, page: currentPage || 1, stype: params.get('stype') || '', svalue: params.get('svalue') || ''}
        Promise.resolve(this.props.onGetPosts(searchParams)).then((totalPage) => {
            if (this._isMounted) {
                this.setState({page: {...this.state.page, current: Number(currentPage) || 1, total: Number(totalPage) }})
                this.handlePageList(currentPage, totalPage)
            }
        })
    }

    render() {
        const { id, totalPage } = this.props, { page } = this.state
        return (
            <Paginator 
            id={id} page={page} totalPage={totalPage}
            onCurrentPage={this.handleCurrentPage}
            onIncrementPage={this.handleIncrementPage} 
            onDecrementPage={this.handleDecrementPage}
            onSkipPrevPage={this.handleSkipPrevPage} 
            onSkipNextPage={this.handleSkipNextPage}
            />
        );
    }
}

export default withRouter(PaginatorContainer)
