import React, { Component } from 'react';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import * as navActions from 'stores/actions/navigate';
// import { NavList, NavItem/* , NavD2List, NavD2Item */ } from 'components/presentational/navbar'
import NavbarPresenter from 'components/widget/navbar/NavbarPresenter'


class NavbarContainer extends Component {
    constructor(){
        super();
        this.state = { open:null };
    }

    componentDidMount() {
        this.props.NavActions.getNavmap()
    }

    // showControl(val) {
    //     // console.log(val)
    //     this.props.NavActions.changeShow({val, depth: 1});
    // }
    showControl = (index) => {
        this.props.NavActions.changeShow({index, depth: 1})
        // console.log(this.props.NavActions.changeShow({val, depth: 1}))
    }
    render() {
        return (
            <NavbarPresenter list={this.props.list} showControl={this.showControl} show={this.props.status.getIn(['show', 0])}/>
        );
    }
}

export default connect(
    (state) => ({
        list: state.navigate.getIn(['globalNav', 'list']),
        status: state.navigate.getIn(['globalNav', 'status']),
    }),
    (dispatch) => ({
        NavActions: bindActionCreators(navActions, dispatch)
    })
)(NavbarContainer);

