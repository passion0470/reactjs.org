import React, { Component } from 'react';
import GlobalPresenter from 'components/global/GlobalPresenter'
import AuthService from 'services/authService'

class GlobalCotainer extends Component {
    componentDidMount() {
        this.handelRefreshIn()
    }

    handelRefreshIn() {
        // if(new AuthService().refreshedIn() === true) new AuthService().refreshIn().then(() => { new AuthService().refreshPolling() })
        if(new AuthService().refreshedIn() && new AuthService().signedIn()) {
            console.log(new AuthService().getTokenInfo())
            new AuthService().refreshIn().then(() => { new AuthService().refreshPolling() }).catch(() => {
                return setTimeout(function() { 
                    new AuthService().refreshIn().then(() => { new AuthService().refreshPolling() 
                    }) }, 10000) 
            })
        }
    }
      
    render() {
        return (
            <GlobalPresenter children={this.props.children} />
        );
    }
}

// 이건 때에 따라선데, 컴포넌트엔 global.jsx가 따로 있을 필요가 없다. board.jsx와 마찬가지로 따로 있을 필요가 없고,
// 오로지 해당 부품만 있으면 되고. 컨테이너는 꼭 필요는 없겠지만, 때에 따라서, 헤더와 메인 대표적인 부분만 가져와서 컨테이너 한후에, 글로벌 컨테이너로 통합할수 있다.
export default GlobalCotainer