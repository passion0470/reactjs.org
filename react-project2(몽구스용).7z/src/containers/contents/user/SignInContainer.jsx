import React, { Component } from 'react';
import SignIn from 'components/contents/user/signin/SignIn'
import AuthService from 'services/authService'
import { withRouter } from "react-router-dom";

class SignInContainer extends Component {
    constructor() {
        super()
        this.state = { email:'', password:'', remember: false, message:'' }
        this.authService = new AuthService();
    }

    componentDidMount() {
        console.log(this.authService.signedIn())
        console.log(this.authService.refreshedIn())
    }

    handleInputChange = ({name, value}) => {
        this.setState({ [name]: value }, ()=> console.log(this.state))
    }

    // handleKeyPress = (e) => {
    //     if (e.key === 'Enter') this.handleSubmit(e);
    // }

    handleSubmit = (e) => {
        if(e) e.preventDefault()
        this.authService.signIn(this.state.email, this.state.password).then(() => { 
            // window.location.reload()
            this.props.history.push('/')
            console.log(this.authService.signedIn())
            console.log(this.authService.refreshedIn())
        })
    }

    render() {
        return (
            <SignIn email={this.state.email} password={this.state.password} remember={this.state.remember} message={this.state.message} onInputChange={this.handleInputChange} onSubmit={this.handleSubmit}/>
        );
    }
}

export default withRouter(SignInContainer)

