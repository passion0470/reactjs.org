import React, { Component } from 'react';
import SignUp from 'components/contents/user/signup/SignUp'
import { regexCheck } from 'utils/validations'
import request from 'services/request'
import { withRouter } from "react-router-dom";

class SignUpContainer extends Component {
    constructor() {
        super()        
        this.state = { 
            user: { email: '', password: '', repassword: '', name: '', birth: '', sex: '', countryCode: '82', phone: '' },
            selection: {
                countryCode: { korea:'82', usa:'1', japan:'81', vietname:'84', hongcong:'852', china:'86', philippines:'63' },
                sex: ['Male', 'Female', 'Other']
            },
            validation: { terms:false, check: { id:false, password:false }, message: { id:'', password:'' } }
        }
    }

    handleValidChange = ({name, value}) => {
        this.setState({validation: {...this.state.validation, [name]: value }}, ()=> console.log(this.state.validation))
    }

    handleInputChange = ({name, value}) => {
        this.setState({user: {...this.state.user, [name]: value }}, ()=> console.log(this.state.user))
    }

    handleValidateMsg() {
        
    }

    handleOverlapCheck() {

    }

    handleValidateCheck() {
        return new Promise((resolve, reject) => {
            if(this.state.validation.terms === false) 
                return (alert('Please accept the terms'), reject())
            else if(regexCheck('email', this.state.user.email)) 
                return (alert('Email format is incorrect'), reject())
            else if(this.state.user.password !== this.state.user.repassword) 
                return (alert('Passwords are not the same'), reject())
            else if(regexCheck('password', this.state.user.password)) 
                return (alert('Password must be 6-15 characters including alphanumeric characters and special characters'), reject())
            else if(this.state.user.phone !== '' && regexCheck('phone', this.state.user.phone)) 
                return (alert('Invalid phone number. (Example: 010-1234-1234)'), reject())
            else 
                return resolve()
                // return (this.setState({validation: {...this.state.validation, fullCheck: true }}, ()=> console.log(this.state.validation)), resolve())
        })
    }

    handleOrganizeValue() {
        let userValue = {}
        userValue.email = this.state.user.email
        userValue.password = this.state.user.password
        userValue.name = this.state.user.name
        userValue.birth = this.state.user.birth === '' ? null : this.state.user.birth
        userValue.sex = this.state.user.sex === '' ? null : this.state.user.sex
        userValue.phone = this.state.user.phone === '' ? null : this.state.user.countryCode + '-' + this.state.user.phone.slice(1)
        return userValue 
    }

    handleSignUpRequest = async () => {
        try {
            const response = await request.post('/signup', this.handleOrganizeValue())
            console.log(response)
            alert('sign up was successful')
            Promise.resolve(response)
        } catch (e) {
            console.log(e)
            alert('sign up Failure')
            Promise.reject() 
        }
    }

    handleSubmit = (e) => {
        if(e) e.preventDefault()
        this.handleValidateCheck().then(() => {
            this.handleSignUpRequest().then(() => { 
                this.props.history.push('/signin') 
            }) 
            // return new Promise((resolve, reject) => {
                // request.post('/signup', this.handleOrganizeValue()).then(response => {
                //     console.log(response)
                //     alert('sign up was successful')
                //     resolve()
                // }).catch(error => { 
                //     console.log(error)
                //     alert('sign up Failure')
                //     reject() 
                // })
            // }).then(() => { this.props.history.push('/signin') }) 
        }) 
    }

    render() {
        return (
            <SignUp user={this.state.user} selection={this.state.selection} validation={this.state.validation} onInputChange={this.handleInputChange} onValidChange={this.handleValidChange} onSubmit={this.handleSubmit} />
        );
    }
}

export default withRouter(SignUpContainer)
