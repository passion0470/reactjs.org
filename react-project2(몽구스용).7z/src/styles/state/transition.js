import { css } from 'styled-components'

export const transition = css`

    /* .is-fade-page { animation-duration: 0.5s; animation-name: is-fade-page; }
    @keyframes is-fade-page {
        from { opacity: 0.01; transition: opacity 30ms ease-in;  }
        to { opacity: 1; transition: opacity 30ms ease-in; }
    } */

    .slide {
        &-enter {transition: height .3s ease;
            &.slide-enter-active {transition: height .3s ease;}
        }
        &-exit {transition: height .3s ease;
            &.slide-exit-active {transition: height .3s ease;} 
        }
    }

    .fade {
        &-enter { opacity: 0.01; transition: opacity 300ms ease-in;
            &.fade-enter-active { opacity: 1; transition: opacity 300ms ease-in; }
        }
        &-exit {opacity: 1; transition: opacity 300ms ease-in;
            &.fade-exit-active {opacity: 0.01; transition: opacity 300ms ease-in;} 
        }
    }

    .fade-page {
        &-enter { opacity: 0.01; transition: opacity 300ms ease-in;
            &.fade-page-enter-active { opacity: 1; transition: opacity 300ms ease-in; }
        }
        &-exit {opacity: 1;
            &.fade-page-exit-active {opacity: 0; } 
        }
    }

    .slideMove {
        &-enter { margin-bottom:-300px; transition-duration: 0.5s;
            &.slideMove-enter-active { margin-bottom:0; transition-duration: 0.5s;}
        }
        &-exit { margin-bottom:0; transition-duration: 0.5s;
            &.slideMove-exit-active {  margin-bottom:-300px; transition-duration: 0.5s;} 
        }
    }

    .dialog-enter {
    opacity: 0.01;
    transform: scale(1.1);
    }

    .dialog-enter-active {
    opacity: 1;
    transform: scale(1);
    transition: all 300ms;
    }

    .dialog-exit {
    opacity: 1;
    transform: scale(1);
    }

    .dialog-exit-active {
    opacity: 0.01;
    transform: scale(1.1);
    transition: all 300ms;
    }
    `

export default transition
