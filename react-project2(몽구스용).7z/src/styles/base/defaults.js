import { css } from 'styled-components'

export const defaults = css`
    html { background: #f0f0f0 }
`

export default defaults
