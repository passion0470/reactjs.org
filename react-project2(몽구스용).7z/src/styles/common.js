import { createGlobalStyle } from 'styled-components';
import normalize from './base/normalize';
import defaults from './base/defaults';
import transition from './state/transition';
import table from './module/table';

const GlobalStyles = createGlobalStyle`
    ${normalize}
    ${defaults}
    ${transition}
    ${table}
`;

export default GlobalStyles;
