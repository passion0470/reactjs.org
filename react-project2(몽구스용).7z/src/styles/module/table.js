
import { css } from 'styled-components'

const tbBorder = '1px solid #dadada'

export const table = css`

/*Basic 테이블*/
/* Basic 테이블 공통 */
.tb-1, .tb-2, .tb-3 { width:100%; border-top: 1px solid #4faadc; 
    th, td { padding: 7px; font-size:12px;
        border: { left: ${tbBorder}; right: ${tbBorder}; } 
    }
    th { font-family: 'NanumGothicBold'; vertical-align: middle;} 
    tr { border-bottom: ${tbBorder}; }
} 

/* Basic 테이블1 */
.tb-1 {
    th { text-align: center; border-bottom: 2px solid #dadada; }
    tr { 
        border: { left: hidden; right: hidden; }
    }
    tbody tr {
        &:nth-child(odd) {background:#f3f3f3;}
        &:hover { background: #ededed; }    
    }
    td { text-align:center; } 
}

/* Basic 테이블2 */
.tb-2 { 
    tbody th { background: transparent; }
}

/* 테이블3 */
.tb-3 { 
    td, tr { 
        border: { left: hidden; right: hidden; }
    }
    th { width: 140px; text-align: left; background: #efefef; text-indent:5px;}
}

/* 테이블 바디 스크롤 */
.grid-scroll {  padding:30px 0; position:relative; width:100%;
    .grid-scroll-inside { overflow:auto; height:153px; }
    table { width:100%; border:0; table-layout: fixed; 
        caption { height:0; overflow:hidden; }
        thead, tfoot { position:absolute; display:table; table-layout: fixed; /* width:100%; */ width:calc(100% - 18px) }
        thead { top:0; border-top: 1px solid #666666; }
        tbody {bottom:0;}
    }
}

/*그리드*/
`
export default table



