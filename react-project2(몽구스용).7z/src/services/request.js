import axios from 'axios'
import AuthService from './authService';

const request = axios.create({
  // baseURL: 'http://localhost:8081/api',
  baseURL: 'http://localhost:8082/api',
  // baseURL: 'http://localhost:3000/api',
  timeout: 10000
})

// request interceptor
// 요청 설정
request.interceptors.request.use(config => {
  // TODO : auth 인증 관련
  if(new AuthService().signedIn()) 
    config.headers.Authorization = new AuthService().getToken().token_type + ' ' + new AuthService().getToken().access_token;

  return config
})

// respone interceptor
// 반환 설정
request.interceptors.response.use(response => {
    // console.log(response)
    // TODO : auth 인증 관련
    return new AuthService()._checkStatus(response)
    // return response
  }, error => {
    // console.log(error.response)
    // console.log(error.config)
    return Promise.reject(error)    
  }
)

export default request
