import axios from 'axios'
import request from './request'


// 클래스기에, 대문자로 바꿔주는게 나을지도 모르는데... 음..

export default class AuthService {
    // Initializing important variables
    constructor(/* domain */) {
        // this.domain = domain || 'http://localhost:8080' // API server domain
        // this.fetch = this.fetch.bind(this) // React binding stuff
        this.signIn = this.signIn.bind(this)
        this.getProfile = this.getProfile.bind(this) 
        this.tokenKey = "TOKEN"
    }

    async signIn(email, password) {
        // Get a token from api server using the fetch api
        // new Promise((resolve, reject) => {
        //     return request.post('/signin', {email, password}).then(response => {
        //         console.log(response)
        //         this.setToken(response.data) // Setting the token in localStorage
        //         alert('sign up success')
        //         resolve(response);
        //     }).catch(error => { 
        //         console.log(error)
        //         alert('sign up failure')
        //         reject(error);
        //     })
        // })
        try {
            const response = await request.post('/signin', {email, password})
            console.log(response)
            this.setToken(response.data) // Setting the token in localStorage
            alert('sign up success')
            Promise.resolve()
        } catch (e) {
            console.log(e)
            alert('sign up failure')
            Promise.reject()
        }
    }


    async refreshIn() {
        // const refreshToken = this.getToken() ? this.getToken().token_type + ' ' + this.getToken().refresh_token : null
        // const accessToken = this.getToken() ? this.getToken().token_type + ' ' + this.getToken().access_token : null
        // return axios.post('http://localhost:5000/refresh', null, { headers: {Authorization: refreshToken} }).then(response => {
        //     // console.log(response)
        //     console.log("리프레쉬 토큰")
        //     let token = this.getToken()
        //     token.access_token = response.data.access_token
        //     this.setToken(token) // Setting the token in localStorage
        //     Promise.resolve(response);
        // }).catch(error => { 
        //     // console.log(error)
        //     this.removeToken()
        //     Promise.reject(error);
        // })
        const tokenHelper = token => this.getToken() ? this.getToken().token_type + ' ' + this.getToken()[token] : null
        const headers = { headers: {Authorization: tokenHelper('refresh_token'), 'X-Access-Token': tokenHelper('access_token')} }
        const response = await axios.post('http://localhost:8082/api/retoken', {}, headers).catch(e => console.log(e.response))
        
        if(response) {
            console.log("리프레쉬 토큰")
            let token = this.getToken()
            token.access_token = response.data.access_token
            this.setToken(token) // Setting the token in localStorage
        }
        // Promise.resolve(response);
        // try {
        //     const response = await axios.post('http://localhost:8082/api/retoken', {}, headers)
        //     console.log("리프레쉬 토큰")
        //     let token = this.getToken()
        //     token.access_token = response.data.access_token
        //     this.setToken(token) // Setting the token in localStorage
        //     Promise.resolve(response);
        // } catch (e) {
        //     // console.log(e)
        //     // this.removeToken()
        //     Promise.reject(e);
        // }
    }

    refreshPolling() {
        let refreshPoling = setInterval(function () { 
            if(this.refreshedIn()) this.refreshIn()
            else clearInterval(refreshPoling)
        }.bind(this), (this.getToken().expires_in*1000) - 3000); 
    }

    signedIn() {
        // Checks if there is a saved token and it's still valid
        const token = this.getToken() ? this.getToken().access_token : null // GEtting token from localstorage
        return !!token && !this.isTokenExpired(token) // handwaiving here
    }

    refreshedIn() {
        // console.log(this.getToken(), this.getToken().refresh_token)
        const token = this.getToken() ? this.getToken().refresh_token : null// GEtting token from localstorage
        return !!token && !this.isTokenExpired(token) // handwaiving here
    }

    isTokenExpired(token) {
        try {
            const decoded = JSON.parse(atob(token.split('.')[1]))
            // console.log(decoded)
            return decoded.exp < Date.now() / 1000 ? true : false // Checking if token is expired. N
        } catch (err) { 
            return false 
        }
    }

    getTokenInfo() {
        const tokenInfo = this.getToken() ? this.getToken().access_token.split('.')[1] : null
        // console.log( JSON.parse(atob(tokenInfo)) )
        return tokenInfo ? JSON.parse(atob(tokenInfo)) : false 
    }

    async signOut() {
        // Clear user token and profile data from localStorage
        // 로컬스토리지 등 삭제하고, 서버에서도 모든 정보 삭제, 리프레시 토큰 포함 삭제 api 구현
        // return this.removeToken()
        const tokenHelper = token => this.getToken() ? this.getToken().token_type + ' ' + this.getToken()[token] : null
        const headers = { headers: {Authorization: tokenHelper('refresh_token'), 'X-Access-Token': tokenHelper('access_token')} }
        try {
            // const response = await axios.delete('http://localhost:8082/api/signout', headers).then(() => { this.removeToken() })
            const response = await axios.delete('http://localhost:8082/api/signout', headers).then(() => { this.removeToken() }).catch(() => {
                this.removeToken()
            })
            throw response
        } catch (e) {
            this.removeToken()
            throw e
        }
    }

    setToken(tokenId) {
        // Saves user token to localStorage
        if (typeof tokenId === "object") { tokenId = JSON.stringify(tokenId); }
        return localStorage.setItem(this.tokenKey, tokenId);
    }

    getToken() {
        // Retrieves the user token from localStorage
        try { 
            return JSON.parse(localStorage.getItem(this.tokenKey));
        } catch(err) {
            console.log("JSON parse failed for lookup of ", this.tokenKey, "\n error was: ", err);
            return null;
        }
    }

    removeToken() {
        return (localStorage.removeItem(this.tokenKey), window.location.reload())
    }

    getProfile() {
        // Using jwt-decode npm package to decode the token
        return JSON.parse(atob(this.getToken().split('.')[1]))
    }


    // fetch(url, options) {
    //     // performs api calls sending the required authentication headers
    //     const headers = {
    //         'Accept': 'application/json',
    //         'Content-Type': 'application/json'
    //     }

    //     // Setting Authorization header
    //     // Authorization: Bearer xxxxxxx.xxxxxxxx.xxxxxx
    //     if (this.loggedIn()) {
    //         headers['Authorization'] = 'Bearer ' + this.getToken()
    //     }

    //     return fetch(url, {
    //         headers,
    //         ...options
    //     })
    //         .then(this._checkStatus)
    //         .then(response => response.json())
    // }

    _checkStatus(response) {
        // raises an error in case response status is not a success
        if (response.status >= 200 && response.status < 300) { // Success status lies between 200 to 300
            // console.log(response)
            return response
        } else {
            const error = new Error(response.statusText)
            error.response = response
            // console.log(error)
            throw error
        }
    }
}