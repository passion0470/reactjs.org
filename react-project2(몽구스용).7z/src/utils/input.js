// export function toEmptyValue(object) {
//     let status = false
//     Object.keys(object).forEach(key => {
//         if([''].includes(object[key]) === true) return status = true
//     })
//     return status
// }


export function toEmptyValue(object) {
    let status = false
    Object.keys(object).forEach(key => {
        if(![''].includes(object[key])) return status = true
    })
    return status
}


export function toFormData(object) {
    const formData = new FormData();
    Object.keys(object).forEach(key => formData.append(key, object[key]));
    return formData;
}

export function syntObjectToFormData(obj, rootName, ignoreList) {
    const formData = new FormData();
  
    function appendFormData(data, root) {
        if (!ignore(root)) {
            root = root || '';
            if (data instanceof File) {
                formData.append(root, data);
            } else if (Array.isArray(data)) {
                for (let i = 0; i < data.length; i++) appendFormData(data[i], root + '[' + i + ']');
            } else if (typeof data === 'object' && data) {
                for (let key in data) {
                    if (data.hasOwnProperty(key)) root === '' ? appendFormData(data[key], key) : appendFormData(data[key], root + '.' + key)
                }
            } else {
                if (data !== null && typeof data !== 'undefined') formData.append(root, data);
            }
        }
    }

    function ignore(root){
        return Array.isArray(ignoreList)
            && ignoreList.some(function(x) { return x === root; });
    }
  
    appendFormData(obj, rootName);
    return formData;
}


export function downFile(data, originName, type) {
    // mime-type을 명시 적으로 설정하여 새 blob 객체를 만든다. 그렇지 않으면 크롬만 작동
    const newBlob = new Blob([data], {type: type})

    // IE: IE는 blob 객체를 링크 href로 직접 사용의 허용 않는다. 대신 msSaveOrOpenBlob를 사용한다
    // if (window.navigator && window.navigator.msSaveOrOpenBlob) {
    //     window.navigator.msSaveOrOpenBlob(newBlob)
    //     return
    // }

    // IE외: blob을 포함하는 ObjectURL을 가리키는 링크를 만든다
    const dataUrl = window.URL.createObjectURL(newBlob)
    const link = document.createElement('a')
    link.href = dataUrl 
    link.download = originName
    link.click()

    // setTimeout(function () {
    //     // Firefox의 경우 ObjectURL 해지를 지연한다
    //     window.URL.revokeObjectURL(data)
    // }, 100)
}