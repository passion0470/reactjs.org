export class SearchParams {
    constructor(props) { this.props = props }
    
    get = (val) => { return new URLSearchParams(this.props.location.search).get(val) }

    set = (key, val) => { return new URLSearchParams(this.props.location.search).set(key, val) }

    del = (key) => { return new URLSearchParams(this.props.location.search).delete(key) }

    has = (key) => { return new URLSearchParams(this.props.location.search).has(key) }

    add = (key, val) => { return new URLSearchParams().append(key, val) }

    setAll = (val) => {
        return this.props.history.push({
            pathname: this.props.location.pathname, 
            search: "?" + new URLSearchParams(val).toString()
        })
    }
}