// import * as BOARD from 'stores/actions/board';
import { board } from 'stores/actions/board';
import { handleActions } from 'redux-actions';
import { fromJS } from 'immutable';

// initial state
const initialState = fromJS({
    status: { id: null, isEdit: false, isEtype: '', totalPage: 0 },
    // status: { id: null, edit: { status: false, type: '' }, totalPage: 0 },
    // edit: { 
    //     post: { id:null, title: '', body: '', tags: [] }, reply: { id:null, body: '', parent: -1, depth: 1 } 
    // },
    info: {},
    posts: [],
    post: { },
    replys: [],
    files: []
});
// 0은 값이 없는 쓰기, 1은 수정, 때론 한국식 리플이나, 혹은 전달이라던지 그런것도 감안. 물론 필요 없겠지만, 예외적 상황 고려
// 쓰기를 1로 하는게 나을듯..
// 0은 쓰기, 1은 수정, 2는 리플라이 쓰기, 3은 리플라이 수정, 아냐아냐, 네임값을 그대로 보낸다. 읽기 쉽다 그러는게
// ID값을 읽고, 쿼리스트링과 별개로, 다른데 이동해도 처리할수 있도록, ID값을 저장. 
// 타입은 네임값을 읽고, 네임값에 따라 분기처리. 타입은 기본적으로, 네임값으로 설정해도 될듯..
// 즉 이런 상태값 변경은, 액티브 에디터를 열때 일어나야하고, 글을 쓰거나, 수정을 하거나, 리플라이를 쓰거나 수정할때 상태값 체크가 필요하다.

// 그럼 해야할일, 로직
// 첫째, 액티브 에디트를 부를떄, 해당 클릭의 네임값을 읽고, etype을 변경해준다. 
// 캔슬 처리시엔 초기화해준다.
// 단 이게, 리플라이용인지, 포스트인지 구별하기 위해, reply, post등 점처리가 필요할수도
// 해당 네임에 따라서, 글쓰기는, 빈값처리, 수정은 포스트에 글 필요한 부분을 덮어 씌우기, 리플라이도 마찬가지.. 
// 마찬가지로, 글쓰기엔, postID를 초기화시키고, 수정시엔 상태값에 따라, postId에 삽입시킨다. 리플라이는 무조건 PostID에 삽입시킨다.
// 이부분은, 포스트를 벗어날때도 상태값이 존재해야하기에, 포스트를 읽을때가 아닌, 버튼을 클릭한 기준으로 이뤄줘야한다.

// 그리고 보낼때는
// 보낼때는, (포스트를 벗어났을때 감안해야하기에) 에디터에서 타입을 체크하고, 쓰기면 그냥 보내고, 포스트 수정이면, postId값을 인수로 보낸다.
// 리플라이는 에디터 타입을 체크하고, 리플라이 쓰기면, 포스트 id등을 인수로 보내 보내고, 수정이면, 마찬가지로 패치로 해서, id를 인수로 보낸다.
// 그리고 다시 불러들이는 작업을 한다.

// JSON.stringify(data)
// JSON.parse(re)

// reducer
// 혹은 리듀셔를 종류별로 나눠, 컴바인시킨다.
export default handleActions({
    [board.INITIALIZE]: (state, action) => initialState,
    [board.INIT_POST]: (state) => {
        return state.set('post', fromJS({ id:null, title: '', body: '', tags: [] }))
    },
    [board.ACTIVE_EDIT]: (state, action) => {
        return state.setIn(['status', 'isEtype'], action.payload).setIn(['status', 'isEdit'], !state.getIn(['status', 'isEdit']))
    },
    [board.CHANGE_INPUT]: (state, action) => {
        const { name, value } = action.payload;
        return state.setIn(['edit', name], value)
    },
    [board.CHANGE_POST]: (state, action) => {
        action.payload.title && state.setIn(['post', 'title'], fromJS(action.payload.title) )
        action.payload.body && state.setIn(['post', 'body'], fromJS(action.payload.body) )
        action.payload.tags && state.setIn(['post', 'tags'], fromJS(action.payload.tags) )
    },
    [board.CHANGE_ETYPE]: (state, action) => {
        // console.log(action.payload)
        return state.setIn(['status', 'etype'], fromJS(action.payload));
    },
    [board.GET_BOARD]: (state, action) => {
        // console.log(action.payload)
        return state.set('info', fromJS(action.payload.data))
    },
    [board.GET_POSTS]: (state, action) => {
        // console.log(action.payload)
        return state.set('posts', fromJS(action.payload.data))
                // .setIn(['status', 'id'], Number(action.payload.id))
                .setIn(['status', 'totalPage'], Number(action.payload.totalPage))
    },
    [board.GET_POST]: (state, action) => {
        // console.log(action.payload)
        return state.set('post', fromJS(action.payload.data))
    },
    [board.GET_REPLYS]: (state, action) => {
        // console.log(action.payload)
        return state.set('replys', fromJS(action.payload.data));
    },
    [board.INIT_REPLYS]: (state) => {
        // console.log(action.payload)
        return state.set('replys', fromJS([]));
    },
    [board.GET_FILES]: (state, action) => {
        // console.log(action.payload)
        return state.set('files', fromJS(action.payload.data))
    }
    // [CHANGE_BOARD]: (state, action) => {
    //     console.log(action.payload)
    //     return state.setIn(['current', 'info', 'id'], action.payload);
    // },
    // [CHANGE_INPUT]: (state, action) => {
    //     console.log(action.payload)
    //     return state.setIn(['current', action.payload.name, action.payload.key], action.payload.value);
    // },
    // [CHANGE_PAGE]: (state, action) => {
    //     return state.setIn(['current', 'pagination', 'page', 'current'], action.payload);
    // },
    // [CHANGE_EDIT]: (state, action) => {
    //     return state.setIn(['current', 'status', 'edit'], action.payload);
    // },
}, initialState);

// export default combineReducers({
//     postsBySubreddit,
//     selectedSubreddit
// })

     // 아니지. 네임을 쪼개서? 근데. 문제가.. 리플라이랑 다르단거.. 아니지.. 한개로 할수 있는지는 두고보자, 즉 네임값 처리는 일단 후에, 다시 리펙토링
        // 포스트 id값이나 리플라이id인수값이 필요한지, 기존가져온걸로 될지도 리펙토링
        // 해당 포스트를 반환한다? 리플라이를 반환한다?
        // 일단은 리플라이의 경우는, 수정을 누르는 순간에, 해당 index으로 읽어서 해당 인덱스로 반환하는게 맞는것 같다.
        // 일단은 리플라이는 빼고, 인덱스로 반환해서 처리한다고만 생각하자. 일단은 그게 맞을듯하고, 나머지는 나중에 수정.. 리플라이는 일단 이걸로 하고 빼자.
        // 아니면, 뷰 용도용 상태값, 리플라이 뷰 용도용 상태값을 가지면 되지 않을까?
        // 고민해보자. 즉. 실제 포스트와 리플라이 값과 컨테이너의 상태값을 분리하자..
        // 상태값에 에디터값으로 해두는게 좋냐, 뷰값으로 해두는게 좋냐의 여부 고민..
        // 상태는 에디터로 해두는게 좋겠다.
        // 대신에 스타튜스는 공유하자 리덕스로