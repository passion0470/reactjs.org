// import * as MODAL from 'stores/actions/modal';
import { modal } from 'stores/actions/modal';
import { handleActions } from 'redux-actions';
import { fromJS } from 'immutable';

// initial state
const initialState = fromJS({
    status: 0
 });
 
// reducer
export default handleActions({
    [modal.INITIALIZE]: (state, action) => initialState,
    [modal.SHOW_MODAL]: (state, action) => {
        return state.set('status', action.payload);
    },
}, initialState);