import * as NAV from 'stores/actions/navigate';
import { handleActions } from 'redux-actions';
import { fromJS } from 'immutable';

// initial state
const initialState = fromJS({
    globalNav: {
        status: { show:[null, null] },
        list: {},
    },
    toolNav: {
        list: {}
    } 
});

// reducer
export default handleActions({
    [NAV.INITIALIZE]: (state, action) => initialState,
    [NAV.GET_NAVIGATE]: (state, action) => {
        const { globalNav, toolNav } = action.payload.data
        return state.setIn(['globalNav', 'list'], fromJS(globalNav)).setIn(['toolNav', 'list'], fromJS(toolNav))
    },
    [NAV.CHANGE_SHOW]: (state, action) => {
        console.log(action.payload.index)
        return state.setIn(['globalNav', 'status', 'show', action.payload.depth-1], action.payload.index) 
    },
}, initialState);