import * as PAGE from 'stores/actions/paginate';
import { handleActions } from 'redux-actions';
import { fromJS } from 'immutable';

// initial state
const initialState = fromJS({
    row: { total:null, limit:10 }, 
    page: { total:14, current:1, limit: 5 }
});


// reducer
export default handleActions({
    [PAGE.INITIALIZE]: (state, action) => initialState,
    [PAGE.TOTAL]: (state, action) => {
        return state.setIn(['page', 'total'], Number(action.payload.totalPage))
    },
    [PAGE.CURRENT]: (state, action) => {
        return state.setIn(['page', 'current'], Number(action.payload.page))
    }
    // [PAGE.INCREMENT]: (state) => {
    //     return state.setIn(['page', 'current'], Number(state.getIn(['page', 'current'])) + 1)
    // },
    // [PAGE.DECREMENT]: (state) => {
    //     return state.setIn(['page', 'current'], Number(state.getIn(['page', 'current'])) - 1)
    // },
}, initialState);

// 토탈값을 임의로 주고 작업