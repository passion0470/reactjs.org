import React from 'react';
import { createStore, applyMiddleware, compose, combineReducers } from 'redux';
import * as reducers from './reducers'
import ReduxThunk from 'redux-thunk'

const reducerCombine = combineReducers(reducers)
const middlewares = applyMiddleware(...[ReduxThunk])

// 개발 모드일 때만 Redux Devtools를 적용
const isDev = process.env.NODE_ENV === 'development'
const devtools = isDev && window.__REDUX_DEVTOOLS_EXTENSION_COMPOSE__;
const composeEnhancers = devtools || compose;

export const Context = React.createContext(null);
export default createStore(reducerCombine, composeEnhancers(middlewares))
