// import { createAction } from 'redux-actions';
// import { createActions } from 'redux-actions';
// import { modal } from 'stores/types';

// action types
// export const INITIALIZE = 'modal/INITIALIZE'
// export const SHOW_MODAL = 'modal/SHOW_MODAL'

// action creators
// export const initialize = createAction(INITIALIZE)
// export const modalShow = createAction(SHOW_MODAL)

// action types
export const modal = {
    INITIALIZE: 'modal/INITIALIZE',
    SHOW_MODAL: 'modal/SHOW_MODAL',
}

// action creators
export const modalActions = {
    initialize: () => dispatch => { 
        dispatch({ type: modal.INITIALIZE })
    },
    modalShow: (id) => dispatch => { 
        dispatch({ type: modal.SHOW_MODAL, payload: id })
    }
} 

// 둘다 디스패치로 가는건 마찬가지일듯 하다. 취향에 따라 쓰면 될듯하다. retrun을 하고 안하고 차이가 있겠다.
// initialize: () => dispatch => { 
//     dispatch({ type: MODAL.INITIALIZE })
// },
// initialize: () => { 
//     return { type: MODAL.INITIALIZE }
// },



// export const modalActions = createActions({
//     initialize: () => dispatch => { 
//         return dispatch({ type: INITIALIZE })
//     },
//     modalShow: (id) => dispatch => { 
//         return dispatch({ type: SHOW_MODAL, payload: id })
//     }
// })   

// import { createActions } from 'redux-actions';

// export const INITIALIZE = 'INITIALIZE'
// export const SHOW_MODAL = 'SHOW_MODAL'

// export const { initialize, modalShow } = createActions({
//     INITIALIZE: () => (INITIALIZE),
//     SHOW_MODAL: (id) => (id)
// });

// export const { initialize, modalShow } = createActions('INITIALIZE', 'SHOW_MODAL');

// export const { initialize, modalShow } = createActions({
// }, INITIALIZE, SHOW_MODAL);
