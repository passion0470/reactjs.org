import { createAction } from 'redux-actions';

// action types
export const INITIALIZE = 'page/INITIALIZE'
export const TOTAL = 'page/TOTAL'
export const CURRENT = 'page/CURRENT'
// export const INCREMENT = 'page/INCREMENT'
// export const DECREMENT = 'page/DECREMENT'

// action creators
export const initialize = createAction(INITIALIZE)
export const total = createAction(TOTAL)
export const current = createAction(CURRENT)
// export const increment = createAction(INCREMENT)
// export const decrement = createAction(DECREMENT)

