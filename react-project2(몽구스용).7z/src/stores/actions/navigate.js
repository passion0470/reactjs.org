import { createAction } from 'redux-actions';
import axios from 'axios'

// action types
export const INITIALIZE = 'nav/INITIALIZE'
export const CHANGE_SHOW = 'nav/CHANGE_SHOW'
// export const GET_GLOBALNAV = 'nav/GET_GLOBALNAV'
// export const GET_TOOLNAV = 'nav/GET_TOOLNAV'
export const GET_NAVIGATE = 'nav/GET_NAVIGATE'

// action creators
export const initialize = createAction(INITIALIZE)

// 퍼블릭이나 스태틱은 URL 전부 적어주는게 좋을 듯 하다. 리퀘스트로 해도 된다. 하지만 적합성을 따진다. 네이게이션은 필요없을듯

export const getNavmap = () => async dispatch => {
    const response = await axios.get('http://localhost:3001/data/navmap.json')
    return dispatch({ type: GET_NAVIGATE, payload: response })
}
export const changeShow = ({index, depth}) => dispatch => {
    dispatch({ type: CHANGE_SHOW, payload: {index:index, depth:depth} })
}

// export const getGlobalNav = () => async dispatch => {
//     const response = await axios.get('http://localhost:3000/data/navigate.json')
//     return dispatch({type: GET_GLOBALNAV, payload: response})
// }
// export const getToolNav = () => async dispatch => {
//     const response = await axios.get('http://localhost:3000/data/navigate.json')
//     return dispatch({type: GET_TOOLNAV, payload: response})
// }


// import { createActions } from 'redux-actions';
// export const INITIALIZE = 'INITIALIZE'
// export const CHANGE_SHOW = 'CHANGE_SHOW'

// export const { initialize, changeShow } = createActions('INITIALIZE', 'CHANGE_SHOW');

// export const { initialize, changeShow } = createActions({
//     [INITIALIZE]: () => (INITIALIZE),
//     [CHANGE_SHOW]: ({val, depth}) => ({val, depth})
// });

// export const { initialize, changeShow } = createActions({
// }, INITIALIZE, CHANGE_SHOW);

// export const actions = combineActions({ initialize, changeShow })

