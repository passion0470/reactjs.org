// import {TOTAL} from 'stores/actions/paginate';
// import { createAction, createActions } from 'redux-actions';
import request from 'services/request'
// import { board } from 'stores/types';

// action types
export const board = {
    INITIALIZE: 'board/INITIALIZE',
    CHANGE_BOARD: 'board/CHANGE_BOARD',
    CHANGE_INPUT: 'board/CHANGE_INPUT',
    ACTIVE_EDIT: 'board/ACTIVE_EDIT',
    GET_BOARD: 'board/GET_BOARD',
    GET_POSTS: 'board/GET_POSTS',
    GET_POST: 'board/GET_POST',
    GET_REPLYS: 'board/GET_REPLYS',
    CHANGE_PAGE: 'board/CHANGE_PAGE',
    INIT_POST: 'board/INIT_POST',
    CHANGE_ETYPE: 'board/CHANGE_ETYPE',
    CHANGE_POST: 'board/CHANGE_POST',
    INIT_REPLYS: 'board/INIT_REPLYS',
    GET_FILES: 'board/GET_FILES'
}

// action creators
export const boardActions = {
    initialize: () => dispatch => { 
        dispatch({ type: board.INITIALIZE })
    },
    changePost: (post) => dispatch => { 
        dispatch({ type: board.CHANGE_POST, payload: post })
    },
    activeEdit: (name) => dispatch => { 
        dispatch({ type: board.ACTIVE_EDIT, payload: name })
    },
    initPost: () => dispatch => { 
        dispatch({ type: board.INIT_POST })
    },
    initReplys: () => dispatch => { 
        dispatch({ type: board.INIT_REPLYS })
    },
    changeInput: (payload) => dispatch => { 
        dispatch({ type: board.CHANGE_INPUT, payload: payload })
    },
    getBoard: () => async dispatch => {
        const response = await request.get('/board');
        dispatch({type: board.GET_BOARD, payload: response})
    },
    getPosts: (payload) => async dispatch => {
        const response = await request.get('/board/posts', {params:payload});
        const metaData = JSON.parse(response.headers["x-meta-data"])
        console.log(response.data)
        dispatch({type: board.GET_POSTS, payload: {data: response.data, id: metaData.boardId, totalPage: metaData.totalPage} })
        return metaData.totalPage
    },
    getPost: (id) => async dispatch => {
        const response = await request.get('/board/post', {params: {id: id}});
        dispatch({type: board.GET_POST, payload: response})
    },
    patchPost: ({post, id, postId}) => async dispatch => {
        console.log({post, id, postId})
        const response = await request.put('/board/post', post, {params: {id: id, postId: postId}});
        dispatch({type: board.GET_POST, payload: response})
    },
    deletePost: ({postId}) => async dispatch => {
        const response = await request.delete('/board/post', {params: { postId: postId }});
        dispatch({type: board.GET_POST, payload: response})
    },
    postInsert: (id, post) => async dispatch => {
        const response = await request.post('/board/post', post, {params: {id: id}})
        dispatch({type: board.GET_POST, payload: response})
        return response.data
    },
    getReplys: (postId) => async dispatch => {
        // const response = await request.get('/board/comments', {params: {postId: postId}})
        const response = await request.get('/board/reply', {params: {postId: postId}})
        dispatch({type: board.GET_REPLYS, payload: response})
    },
    postReply: ({reply, postId}) => async dispatch => {
        // const response = await request.post('/board/comment', reply, {params: {postId: postId}})
        const response = await request.post('/board/reply', reply, {params: {postId: postId}})
        return response
        // return dispatch({type: GET_REPLY, payload: response})
    },
    // patchReply: ({reply, replyId}) => async dispatch => {
    //     // const response = await request.patch('/board/comment', reply, {params: {replyId: replyId}})
    //     const response = await request.patch('/board/reply', reply, {params: {replyId: replyId}})
    //     return response
    // }    
    patchReply: ({reply, replyId}) => async dispatch => {
        // const response = await request.patch('/board/comment', reply, {params: {replyId: replyId}})
        const response = await request.put('/board/reply', reply, {params: {replyId: replyId}})
        return response
    },
    postFile: ({file, postId}) => async () => {
        const response = await request.post('/board/file', file, {params: {postId: postId}})
        console.log(response)
        // return response
    },   
    postFiles: ({files, postId}) => async () => {
        const response = await request.post('/board/files', files, {params: {postId: postId}})
        console.log(response)
        // return response
    },   
    getFiles: postId => async dispatch => {
        const response = await request.get('/board/files', {params: {postId: postId}})
        console.log(response)
        dispatch({type: board.GET_FILES, payload: response})
        // return response
    },
    getReadFiles: id => async () => {
        const response = await request.get('/board/readfile', {responseType: 'arraybuffer', params: {id: id}})
        console.log(response)
        return response.data
        // return response
    },
    deleteFile: id => async () => {
        const response = await request.delete('/board/file', {params: {id: id}})
        console.log(response)
        return response.data
    },
    putFile: id => async () => {
        const response = await request.put('/board/file', {params: {id: id}})
        console.log(response)
        return response.data
    },
} 



// 미들웨어의 액션 생성자는 에러가 일어났을때 처리하는 이벤트가 있지 않은 이상, 기본적으로 try catch는 안하는걸 원칙, 어차피 에러메시지는 뜬다.




// export const changePost = (post) => dispatch => { 
//     return dispatch({ type: BOARD.CHANGE_POST, payload: post })
// }
// export const activeEdit = (name) => dispatch => { 
//     return dispatch({ type: BOARD.ACTIVE_EDIT, payload: name })
// }
// export const initPost = () => dispatch => { 
//     return dispatch({ type: BOARD.INIT_POST })
// }
// export const initReplys = () => dispatch => { 
//     return dispatch({ type: BOARD.INIT_REPLYS })
// }
// export const changeInput = (payload) => dispatch => { 
//     return dispatch({ type: BOARD.CHANGE_INPUT, payload: payload })
// }
// export const getBoard = () => async dispatch => {
//     const response = await request.get('/board');
//     return dispatch({type: BOARD.GET_BOARD, payload: response})
// }
// export const getPosts = (payload) => async dispatch => {
//     const response = await request.get('/board/posts', {params:payload});
//     const metaData = JSON.parse(response.headers["x-meta-data"])
//     dispatch({type: BOARD.GET_POSTS, payload: {data: response.data, id: metaData.boardId, totalPage: metaData.totalPage} })
//     return metaData.totalPage
// }
// export const getPost = (id) => async dispatch => {
//     const response = await request.get('/board/post', {params: {id: id}});
//     return dispatch({type: BOARD.GET_POST, payload: response})
// }
// export const patchPost = ({post, id, postId}) => async dispatch => {
//     const response = await request.patch('/board/post', post, {params: {id: id, postId: postId}});
//     return dispatch({type: BOARD.GET_POST, payload: response})
// }
// export const deletePost = ({postId}) => async dispatch => {
//     const response = await request.delete('/board/post', {params: { postId: postId }});
//     return dispatch({type: BOARD.GET_POST, payload: response})
// }
// export const postInsert = (id, post) => async dispatch => {
//     const response = await request.post('/board/post', post, {params: {id: id}})
//     return dispatch({type: BOARD.GET_POST, payload: response})
// }
// export const getReplys = (postId) => async dispatch => {
//     const response = await request.get('/board/comments', {params: {postId: postId}})
//     return dispatch({type: BOARD.GET_REPLYS, payload: response})
// }
// export const postReply = ({reply, postId}) => async dispatch => {
//     const response = await request.post('/board/comment', reply, {params: {postId: postId}})
//     return response
//     // return dispatch({type: GET_REPLY, payload: response})
// }
// export const patchReply = ({reply, replyId}) => async dispatch => {
//     const response = await request.patch('/board/comment', reply, {params: {replyId: replyId}})
//     return response
// }



// export const initialize = createAction(BOARD.INITIALIZE)
// export const changeBoard = createAction(BOARD.CHANGE_BOARD)
// export const changePage= createAction(BOARD.CHANGE_PAGE)

// export const activeEdit = createAction(ACTIVE_EDIT)
// export const initPost = createAction(INIT_POST)
// export const activeEdit = () => ({ type: ACTIVE_EDIT })

// 혹은 크리에이터 액션을 오브젝트로 쓴다.
// 혹은 이렇게..
// export const boardAction = {
//     initialize: createAction(BOARD.INITIALIZE),
//     changeBoard: createAction(BOARD.CHANGE_BOARD),
//     changePage: (post) => dispatch => { 
//         return dispatch({ type: BOARD.CHANGE_POST, payload: post })
//     }
// } 
// 혹은 이런식
// export const boardAction = createActions({
//     initialize: createAction(BOARD.INITIALIZE),
//     changeInput: (payload) => dispatch => { 
//         return dispatch({ type: BOARD.CHANGE_INPUT, payload: payload })
//     },
//     changePage: (post) => dispatch => { 
//         return dispatch({ type: BOARD.CHANGE_POST, payload: post })
//     }
// })   

// 혹은 크레이트 액션스로, 종류별로 나누기, 게시판 쓰기, 삭제나, 혹은 읽기만 하는 전용이나, 리스트 전용이나 등등, 단 미들웨어에 사용못하면 무의미할지도.. 근데 쓸수 있을지도

// export const { initPost, getBoard, getPosts } = createActions({
// export const board = createActions({
// export const edit = createActions({
// export default createActions({
//     activeEdit: () => dispatch => { 
//         return dispatch({ type: ACTIVE_EDIT })
//     }
//     // [ACTIVE_EDIT]: () => dispatch => { 
//     //     return dispatch({ type: ACTIVE_EDIT })
//     // }
// });
// 불러오기: ACTIONEX.INIT_POST 이런 형식, 혹은 컴바인하면 무리 없을수도

// export default combineActions(increment, decrement)


// export const GET_USER_DATA = 'GET_USER_DATA';
// export const getUserData = createAction(GET_USER_DATA, async () => {
//       try {
//           return await getUserInfo(config);
//       } catch (error) {
//           console.log("Error occurred");
//       }
//   },
// );

// const { Types, Creators } = createActions({
//     loginRequest: ['username', 'password'],
//     loginSuccess: ['username'],
//     loginFailure: ['error'],
//     logout: null
//   })
  

// export const initPost = () => { 
//     return { type: INIT_POST }
// }
// 디스패치는 리턴이 필요없는듯..




// export default createActions({
//     changePost: (post) => dispatch => { 
//         return dispatch({ type: CHANGE_POST, payload: post })
//     },
//     activeEdit: (name) => dispatch => { 
//         return dispatch({ type: ACTIVE_EDIT, payload: name })
//     },
//     initPost: () => dispatch => { 
//         return dispatch({ type: INIT_POST })
//     }, 
//     initReplys: () => dispatch => { 
//         return dispatch({ type: INIT_REPLYS })
//     },
//     changeInput: (payload) => dispatch => { 
//         return dispatch({ type: CHANGE_INPUT, payload: payload })
//     },
//     getBoard: () => async dispatch => {
//         const response = await request.get('/board');
//         return dispatch({type: GET_BOARD, payload: response})
//     },
//     getPosts: (payload) => async dispatch => {
//         const response = await request.get('/board/posts', {params:payload});
//         const metaData = JSON.parse(response.headers["x-meta-data"])
//         dispatch({type: GET_POSTS, payload: {data: response.data, id: metaData.boardId, totalPage: metaData.totalPage} })
//         return metaData.totalPage
//     },
//     getPost: (id) => async dispatch => {
//         const response = await request.get('/board/post', {params: {id: id}});
//         return dispatch({type: GET_POST, payload: response})
//     },
//     patchPost: ({post, id, postId}) => async dispatch => {
//         const response = await request.patch('/board/post', post, {params: {id: id, postId: postId}});
//         return dispatch({type: GET_POST, payload: response})
//     },
//     deletePost: ({postId}) => async dispatch => {
//         const response = await request.delete('/board/post', {params: { postId: postId }});
//         return dispatch({type: GET_POST, payload: response})
//     },
//     postInsert: (id, post) => async dispatch => {
//         const response = await request.post('/board/post', post, {params: {id: id}})
//         return dispatch({type: GET_POST, payload: response})
//     },
//     getReplys: (postId) => async dispatch => {
//         const response = await request.get('/board/comments', {params: {postId: postId}})
//         return dispatch({type: GET_REPLYS, payload: response})
//     },
//     postReply: ({reply, postId}) => async dispatch => {
//         const response = await request.post('/board/comment', reply, {params: {postId: postId}})
//         return response
//     },
//     patchReply: ({reply, replyId}) => async dispatch => {
//         const response = await request.patch('/board/comment', reply, {params: {replyId: replyId}})
//         return response
//     }
// });






// export const changeEtype = (etype) => dispatch => { 
//     return dispatch({ type: CHANGE_ETYPE, payload: etype })
// }

// export const getBoard = () => async dispatch => {
//     try { 
//         const response = await request.get('/board');
//         console.log(response)
//         return dispatch({type: GET_BOARD, payload: response}) 
//     } catch(error) { 
//         console.log(error) 
//     }
// }

// function getCoffee() {
//   return new Promise(resolve => {
//     setTimeout(() => resolve('☕'), 2000); // it takes 2 seconds to make coffee
//   });
// }

// async function go() {
//   try {
//     // but first, coffee
//     const coffee = await getCoffee();
//     console.log(coffee); // ☕
//     // then we grab some data over an Ajax request
//     const wes = await axios('https://api.github.com/users/wesbos');
//     console.log(wes.data); // mediocre code
//     // many requests should be concurrent - don't slow things down!
//     // fire off three requests and save their promises
//     const wordPromise = axios('http://www.setgetgo.com/randomword/get.php');
//     const userPromise = axios('https://randomuser.me/api/');
//     const namePromise = axios('https://uinames.com/api/');
//     // await all three promises to come back and destructure the result into their own variables
//     const [word, user, name] = await Promise.all([wordPromise, userPromise, namePromise]);
//     console.log(word.data, user.data, name.data); // cool, {...}, {....}
//   } catch (e) {
//     console.error(e); // 💩
//   }
// }

// go();



// const defaultState = { counter: 10 };
 
// const { increment, decrement } = createActions({
//   INCREMENT: (amount = 1) => ({ amount }),
//   DECREMENT: (amount = 1) => ({ amount: -amount })
// });
 
// const reducer = handleActions(
//   {
//     [combineActions(increment, decrement)]: (
//       state,
//       { payload: { amount } }
//     ) => {
//       return { ...state, counter: state.counter + amount };
//     }
//   },
//   defaultState
// );
 
// export default reducer;