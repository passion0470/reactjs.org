import React, { Component } from 'react';

class P3Test1Page extends Component {
    render() {
        return (
            <div>
                P3Test1Page
            </div>
        );
    }
}

export default P3Test1Page