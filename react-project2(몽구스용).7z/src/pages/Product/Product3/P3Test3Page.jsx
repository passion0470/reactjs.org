import React, { Component } from 'react';

class P3Test3Page extends Component {
    render() {
        return (
            <div>
                P3Test3Page
            </div>
        );
    }
}

export default P3Test3Page