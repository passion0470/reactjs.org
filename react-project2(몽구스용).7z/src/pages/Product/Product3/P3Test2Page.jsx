import React, { Component } from 'react';

class P3Test2Page extends Component {
    render() {
        return (
            <div>
                P3Test2Page
            </div>
        );
    }
}

export default P3Test2Page