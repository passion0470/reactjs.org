import React, { Component } from 'react';

class P2Test1Page extends Component {
    render() {
        return (
            <div>
                P2Test1Page
            </div>
        );
    }
}

export default P2Test1Page