import React, { Component } from 'react';

class P2Test3Page extends Component {
    render() {
        return (
            <div>
                P2Test3Page
            </div>
        );
    }
}

export default P2Test3Page