import React, { Component } from 'react';
import { Switch, Route/* , Redirect */ } from 'react-router-dom'

// import Product1Page from './Product1Page'
// import Product2Page from './Product2Page'
// import Product3Page from './Product3Page'

import P1Test1Page from 'pages/Product/Product1/P1Test1Page'
import P1Test2Page from 'pages/Product/Product1/P1Test2Page'
import P1Test3Page from 'pages/Product/Product1/P1Test3Page'

import P2Test1Page from 'pages/Product/Product2/P2Test1Page'
import P2Test2Page from 'pages/Product/Product2/P2Test2Page'
import P2Test3Page from 'pages/Product/Product2/P2Test3Page'

import P3Test1Page from 'pages/Product/Product3/P3Test1Page'
import P3Test2Page from 'pages/Product/Product3/P3Test2Page'
import P3Test3Page from 'pages/Product/Product3/P3Test3Page'

class CsCenter extends Component {
    render() {
        return (
            <div>
                <Switch>
                    <Route path='/product/product1'>
                        <Route path='/product/product1/p1test1' component={P1Test1Page}/>
                        <Route path='/product/product1/p1test2' component={P1Test2Page}/>
                        <Route path='/product/product1/p1test3' component={P1Test3Page}/>
                        {/* <Redirect to='/product/product1/p1test1'/> */}
                    </Route>
                    <Route path='/product/product2'>
                        <Route path='/product/product2/p2test1' component={P2Test1Page}/>
                        <Route path='/product/product2/p2test2' component={P2Test2Page}/>
                        <Route path='/product/product2/p2test3' component={P2Test3Page}/>
                        {/* <Redirect to='/product/product2/p2test1'/> */}
                    </Route>
                    <Route path='/product/product3'>
                        <Route path='/product/product3/p3test1' component={P3Test1Page}/>
                        <Route path='/product/product3/p3test2' component={P3Test2Page}/>
                        <Route path='/product/product3/p3test3' component={P3Test3Page}/>
                        {/* <Redirect to='/product/product3/p3test1'/> */}
                    </Route>
                    {/* <Redirect to='/product/product1/p1test1'/> */}
                    {/* <Route path='/product/product1' component={Product1Page}/>
                    <Route path='/product/product2' component={Product2Page}/>
                    <Route path='/product/product3' component={Product3Page}/>
                    <Redirect to='/product/product1'/> */}
                </Switch>
            </div>
        );
    }
}

export default CsCenter;