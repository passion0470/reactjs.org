import React, { Component } from 'react';
import NavSideBarContainer from 'containers/widget/NavSideBar/NavSideBarContainer'

class P1Test1Page extends Component {
    render() {
        return (
            <div>
                <NavSideBarContainer id={'product'}/>
            </div>
        );
    }
}

export default P1Test1Page