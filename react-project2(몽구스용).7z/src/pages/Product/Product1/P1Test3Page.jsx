import React, { Component } from 'react';

class P1Test3Page extends Component {
    render() {
        return (
            <div>
                P1Test3Page
            </div>
        );
    }
}

export default P1Test3Page