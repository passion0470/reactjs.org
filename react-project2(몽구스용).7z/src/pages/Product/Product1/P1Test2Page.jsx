import React, { Component } from 'react';

class P1Test2Page extends Component {
    render() {
        return (
            <div>
                P1Test2Page
            </div>
        );
    }
}

export default P1Test2Page