import React, { Component } from 'react';

class NotFoundPage extends Component {
    render() {
        return (
            <div>
                NotFound
            </div>
        );
    }
}

export default NotFoundPage