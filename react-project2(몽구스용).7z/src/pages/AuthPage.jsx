import React, { Component } from 'react';

class AuthPage extends Component {
    render() {
        return (
            <div>
                Auth
            </div>
        );
    }
}

export default AuthPage