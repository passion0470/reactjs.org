import React, { Component } from 'react';
import ClientSerachContainer from 'containers/widget/filter/ClientSerachContainer'

class ForumPage extends Component {
    render() {
        return (
            <div>
                <ClientSerachContainer />
            </div>
        );
    }
}

export default ForumPage;

// 클라이언트 서치는 여기에 상태값을 넣지 않으려면, 리덕스를 써야 한다.