import React, { Component } from 'react';
// import Test2Presenter from 'components/contents/contextTest/TestCom2/Test2Presenter'
import Test1Container from 'components/contents/contextTest/testCom1/Test1Container'

class FAQPage extends Component {
    render() {
        return (
            <div>
                <Test1Container/>
                {/* <Test2Presenter/> */}
            </div>
        );
    }
}

export default FAQPage;