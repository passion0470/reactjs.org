import React, { Component, Fragment } from 'react';
import { Switch, Route, Redirect, withRouter } from 'react-router-dom'

import BoardPage from './BoardPage'
import ForumPage from './ForumPage'
import ContactUsPage from './ContactUsPage'
import FAQPage from './FAQPage'
import GirdPage from './GirdPage'

class CsCenter extends Component {
    render() {
        // console.log(this.props.location)
        // console.log(this.props.history.action)
        // const { location } = this.props
        return (
            <Fragment>
                <Switch>                    
                    <Route path='/cscenter/board' component={BoardPage}/>
                    <Route path='/cscenter/board/:id' component={BoardPage}/>
                    <Route path='/cscenter/forum' component={ForumPage}/>
                    <Route path='/cscenter/contactus' component={ContactUsPage}/>
                    <Route path='/cscenter/faq' component={FAQPage}/>
                    <Route path='/cscenter/grid' component={GirdPage}/>
                    {/* <Redirect to={{ pathname: '/cscenter/board', state: { fadeClass: true } }} /> */}
                    <Redirect to='/cscenter/board' />
                </Switch>
            </Fragment>
        );
    }
}

export default withRouter(CsCenter)
