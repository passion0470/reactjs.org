import React, { Component } from 'react';
import BoardContainer from 'containers/dataview/bbs/board/BoardContainer'

class BoardPage extends Component {
    constructor() {
        super();
        this.state = { 
            csizes: ['5%', '*', '8%', '5%', '5%', '5%', '8%'],
            titles: ['Id', 'Title', 'User', 'Files', 'Reply', 'Liked', 'Hits', 'Date'],
            stypes: ['Title+Body', 'Title', 'Body', 'Name', 'Comments']
        };
    }
    render() {
        const { csizes, titles, stypes } = this.state
        return (
            <div>
                <BoardContainer id={2} titles={titles} csizes={csizes} stypes={stypes} restData={{'data': ''}} />
            </div> 
        );
    }
}

export default BoardPage
// restData보단, sendData가 적절할듯.