import React, { Component } from 'react';
import Breadcrumbs from 'components/widget/breadcrumbs/Breadcrumbs'

class ContactUsPage extends Component {
    render() {
        return (
            <div>
                <Breadcrumbs/>
            </div>
        );
    }
}

export default ContactUsPage;