import React, { Component } from 'react';
import InputContainer from 'containers/element/input/InputContainer'

// 인풋 컨테이너는 실제 컴포넌트와 컨테이너에서 컨텐츠에 있어야 하지만, 테스트 용으로 여기서 작업한다.
class OrganizationPage extends Component {
    constructor (props) {
        super(props)
        this.state = { email: '', tel: '', isAllValid: false  }
        this.checkValid = {}
    }

    handleChange(e) {
        this.checkValid[e.name] = e.isValid
        this.setState({ [e.name]: e.value, isAllValid: (this.checkValid['email'] && this.checkValid['tel']) })
        console.log(this.state)
    }

    render() {
        const emailPattern = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$/
        const asciiFilter = /[^\u0020-\u007e]+/g
        return (
            <div>
                <InputContainer name='email' value={this.state.email} filter={asciiFilter} pattern={emailPattern} onChange={e => this.handleChange(e)} />
                <InputContainer name='tel' value={this.state.tel} filter={/[^0-9-()+]/g} pattern={/^[0-9-()+]+$/} onChange={e => this.handleChange(e)} />
            </div>
        );
    }
}

export default OrganizationPage;