import React, { Component } from 'react';
import ExInputContainer from 'containers/element/input/ExInputContainer'

class LocationPage extends Component {
    constructor (props) {
        super(props)
        this.state = { email: '', tel: '', allok: false }
        this.oks = {}
    }

    handleChange (e) {
        this.oks[e.name] = e.isOK
        this.setState({ [e.name]: e.value, allok: (this.oks['email'] && this.oks['tel']) })
    }
    handleSubmit (e) {
        window.alert(JSON.stringify(this.state))
        e.preventDefault()
    }

    render() {
        // 이메일 패턴
        const emailPat = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$/
        // ASCII 문자 이외 전부
        const asciiFilter = /[^\u0020-\u007e]+/g
        const { email, tel } = this.state
        return (
            <div>
                <form onSubmit={e => this.handleSubmit(e)}>
                    <ExInputContainer name='email' label='메일 주소' value={email} pattern={emailPat} filter={asciiFilter} onChange={e => this.handleChange(e)} />
                    <ExInputContainer name='tel' label='전화 번호' value={tel} filter={/[^0-9-()+]/g} pattern={/^[0-9-()+]+$/} onChange={e => this.handleChange(e)} />
                    <input type='submit' value='전송' disabled={!this.state.allok} />
                </form>
            </div> 
        );
    }
}

export default LocationPage;