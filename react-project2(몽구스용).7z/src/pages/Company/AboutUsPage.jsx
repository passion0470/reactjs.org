import React, { Component } from 'react';
import { ModalContainer, ModalButton} from 'containers/widget/modal'
import { BasicBody/* , BasicFooter */ } from 'components/contents/modal/BasicModal'
import { withRouter } from 'react-router-dom'

class AboutUsPage extends Component {
    // constructor(){
    //     super();
    //     this.state = { modalShow: 0 };
    // }

    // onModalShow = (val) => {
    //     this.setState({modalShow: val }, ()=> console.log(this.state.modalShow))
    // }

    render() {
        // const FooterModal = () => {
        //     return(
        //         <footer>
        //             Class Footer
        //         </footer>
        //     )
        // }
        // const { location } = this.props
        // console.log(location.state ? location.state.transition : false, history)
        const FooterModal = () => <footer>Class Footer2</footer>
        // 정안되면, css 애니메이션을 이용해, 조건에 맞으면, 애니메이션을 일어나는걸로하자, 리다이렉트 상태값등으로 전달받고,
        return (
            // location.state.transition
            <div>
                <ModalButton id={1} children="모달버튼1" className="modal-button" />
                <ModalContainer id={1} title={'Modal Title1'} body={<BasicBody/>} footer={<FooterModal/>} />

                <ModalButton id={2} children="모달버튼2" className="modal-button" />
                <ModalContainer id={2} title={'Modal Title2'} body={<BasicBody/>} footer={<FooterModal/>} />

                {/* <input type="button" value="modalShow" onClick={() => this.onModalShow(1)}/> */}
                {/* {this.state.visible === 1 && <ModalContainer onOpenModal={this.onOpenModal} title={'Modal Title'} body={<BasicBody/>} footer={<FooterModal/>} />} */}
                {/* {this.state.visible === 1 && <ModalContainer onOpenModal={this.onOpenModal} overall={<BasicHeader/>}/>} */}
                {/* <ModalContainer id={1} status={this.state.modalShow} onModalShow={this.onModalShow} title={'Modal Title1'} body={<BasicBody/>} footer={<FooterModal/>} />

                <input type="button" value="modalShow" onClick={() => this.onModalShow(2)}/>
                <ModalContainer id={2} status={this.state.modalShow} onModalShow={this.onModalShow} title={'Modal Title2'} body={<BasicBody/>} footer={<FooterModal/>} /> */}
            </div>
        );
    }
}

export default withRouter(AboutUsPage)