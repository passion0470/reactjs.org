import React, { Component } from 'react';
import TabsContainer from 'containers/widget/tab/TabsContainer'
// import Tabs from 'components/widget/tab/Tabs'

class HistoryPage extends Component {
    render() {
        const FistTab = () => <div>Tab Title</div>
        // 만약 인덱스등 그걸 다른 곳에 알릴 필요있다면, 속성을 추가하거나, 리덕스등 다양한 방법이 있을듯, 일단 컨테이너에 있는 액티브탭의 라벨 값을 읽으면 될듯
        // 만약 특정 클래스를 추가하고 싶다면, 프로퍼티로 전달하면 될듯. 
        return (
            <div>
                <TabsContainer>
                    <div label="tab1" convert={<FistTab/>}>
                        See ya later, <em>Alligator</em>!
                    </div>
                    <div label="Croc">
                        After 'while, <em>Crocodile</em>!
                    </div>
                    <div label="Sarcosuchus">
                        Nothing to see here, this tab is <em>extinct</em>!
                    </div>
                </TabsContainer>
            </div>
        );
    }
}

export default HistoryPage