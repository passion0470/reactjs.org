import React, { Component, Fragment } from 'react';
import { Switch, Route, Redirect, withRouter } from 'react-router-dom'
// import { TransitionGroup, CSSTransition } from 'react-transition-group';

import AboutUsPage from './AboutUsPage'
import HistoryPage from './HistoryPage'
import LocationPage from './LocationPage'
import OrganizationPage from './OrganizationPage'

class Company extends Component {
    // componentDidMount() {
    //     this.props.history.push('/company/aboutus') 
    // }
    // componentDidUpdate() {
    //     if(this.props.location.pathname === '/company') {
    //         this.props.history.push('/company/aboutus') 
    //     }
    // }

    render() {
        // console.log(this.props.location)
        // console.log(this.props.history.action)
        // const { location } = this.props
        // const rePath = '/company/aboutus'
        return (
            <Fragment>
                {/* <TransitionGroup className="transition-group">
                    <CSSTransition key={location.search ? location.search : location.pathname} timeout={{ enter: 500, exit: 0 }} classNames="fade-page"> */}
                        <Switch>
                            {/* 아니면, 타이틀을 네비게이트 json에 적자. 그게 나을수도.. 문제는 해당 키값을 가져오는 문제? 애매하네 */}
                            <Route path='/company/aboutus' render={() => <AboutUsPage title="About Us"/>}/>
                            {/* <Route path='/company/aboutus' component={AboutUsPage}/> */}
                            <Route path='/company/history' component={HistoryPage}/>
                            <Route path='/company/location' component={LocationPage}/>
                            <Route path='/company/organization' component={OrganizationPage}/>
                            {/* <Redirect to={{ pathname: '/company/aboutus', state: { fadeClass: true } }}/> */}
                            <Redirect to='/company/aboutus' />
                        </Switch>
                    {/* </CSSTransition>
                </TransitionGroup> */}
            </Fragment>
        );
    }
}


export default withRouter(Company)

// 결론은 모든 곳에 트랜지션그룹을 주고, 그 안에 라우터를 만드는게 이상적일 듯..
// index.js는
// 일단은 트랜지션 없이 가고, 고민해보자. 깜빡임 해결할떄까지


// 서브페이지로 감싸야할 부분은 컨테이너에서 분기할수도 있겠지만, 여기서 감싸줄수도 있다. 그리고 때론 페이지별로 감싸야할 부분도 있다. 그럴땐 이곳이 요긴하다.