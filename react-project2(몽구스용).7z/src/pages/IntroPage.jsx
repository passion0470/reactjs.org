import React, { Component } from 'react';

class IntroPage extends Component {
    render() {
        return (
            <div>
                Intro
            </div>
        );
    }
}

export default IntroPage