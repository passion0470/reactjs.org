import React, { Component } from 'react';

class HomePage extends Component {
    render() {
        return (
            <div>
                HOME
            </div>
        );
    }
}

export default HomePage