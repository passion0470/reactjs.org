import React, { Component } from 'react';
import SignUpContainer from 'containers/contents/user/SignUpContainer'

class SignUpPage extends Component {
    render() {
        return (
            <div>
                <SignUpContainer/>
            </div>
        );
    }
}

export default SignUpPage;