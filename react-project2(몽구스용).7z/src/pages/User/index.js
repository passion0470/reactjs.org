import React, { Component } from 'react';
import { Switch, Route , Redirect } from 'react-router-dom'

import ProfilePage from './ProfilePage'
import SignInPage from './SignInPage'
import SignUpPage from './SignUpPage'
import ForgotPage from './ForgotPage'

class CsCenter extends Component {
    render() {
        return (
            <div>
                <Switch>
                    <Route path='/user/profile' component={ProfilePage}/>
                    <Route path='/user/signin' component={SignInPage}/>
                    <Route path='/user/signup' component={SignUpPage}/>
                    <Route path='/user/forgot' component={ForgotPage}/>
                    <Redirect to='/user/profile'/> 
                </Switch>
            </div>
        );
    }
}

export default CsCenter;