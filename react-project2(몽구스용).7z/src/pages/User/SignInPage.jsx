import React, { Component } from 'react';
import SignInContainer from 'containers/contents/user/SignInContainer'

class SignInPage extends Component {
    render() {
        return (
            <div>
                <SignInContainer/>
            </div>
        );
    }
}

export default SignInPage;