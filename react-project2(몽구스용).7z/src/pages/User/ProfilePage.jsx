import React, { Component } from 'react';

class ProfilePage extends Component {
    render() {
        return (
            <div>
                
            </div>
        );
    }
}

export default ProfilePage;