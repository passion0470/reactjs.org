import React, { Component } from 'react';
import { HashRouter as Router, Route, Switch } from 'react-router-dom'
// import AuthService from 'services/authService'

import GlobalStyles from './styles/common'
import GlobalCotainer from './containers/global/GlobalCotainer'

import { library } from '@fortawesome/fontawesome-svg-core'
import { faSignInAlt, faUserPlus, faPowerOff, faFileContract, faUserCog, faEnvelope, faUser, faCheck } from '@fortawesome/pro-solid-svg-icons'
library.add(faSignInAlt, faUserPlus, faPowerOff, faFileContract, faUserCog, faEnvelope, faUser, faCheck)

/* eslint-disable import/first */
import IntroPage from 'pages/IntroPage'
import NotFoundPage from 'pages/NotFoundPage'
import Company from 'pages/Company'
import CsCenter from 'pages/CsCenter'
import Product from 'pages/Product'
import User from 'pages/User'


// import axios from 'axios'
import request from 'services/request'

// import AboutUsPage from 'pages/AboutUsPage'
// import HistoryPage from './HistoryPage'
// import LocationPage from './LocationPage'
// import OrganizationPage from './OrganizationPage'

// eslint-disable-next-line
String.prototype.firstCapitalize = function() {
  return this.charAt(0).toUpperCase() + this.slice(1);
}

// function firstCapitalize(string) {
//     return string.charAt(0).toUpperCase() + string.slice(1);
// }

class App extends Component {
  // componentDidMount() {
  //   this.handelRefreshIn()
  // }

  // handelRefreshIn() {
  //   // if(new AuthService().refreshedIn() === true) new AuthService().refreshIn().then(() => { new AuthService().refreshPolling() })
  //   if(new AuthService().refreshedIn() && new AuthService().signedIn()) {
  //     new AuthService().refreshIn().then(() => { new AuthService().refreshPolling() }).catch(() => {
  //         return setTimeout(function() { 
  //             new AuthService().refreshIn().then(() => { new AuthService().refreshPolling() 
  //             }) }, 10000) 
  //     })
  //   }
  // }

  componentDidMount() {
    // this.test()
  }

  async test() {
    // const response = await axios.get('http://localhost:8081/api/test')
    // const response = await request.get('http://localhost:8081/api/test')  
    // // const response = await axios.get('http://localhost:8081/api/test').catch(e => {console.log(e)})
    // console.log(response)
    try {
      // const response = await request.get('http://localhost:8081/api/test', {params: { test: '111'}})  

      const response = await request.post('http://localhost:8081/api/test', { test: '111'})  

      console.log(response)
    } catch (error) {
      // 그냥 텍스트만 가져옴
      // console.log(error)
      // 에러나도, 200처럼, 오브젝트 형식으로 가져옴
      // _checkStatus 때문일까? 아니, 없애도 작동되는거 확인됨.. 즉 원래 있는 부분인듯..
      // 메시지는 statusTest로만 처리하는게 가장 올바른 방법인듯..
      console.log(error.response)
      console.log(error.response.status)
      console.log(error.response.statusText)
      console.log(error.config)
      
      // 즉 리프레쉬 토큰을 이용시, 에러 메시지를 읽고 401이라던지 특정 상태값에 따라서(401이 맞을듯)
      // 리프레쉬 토큰 인증 api호출을 보내고, 성공하면 then으로 오면, 다시 이 api를 재호출하면 된다..
      // 근데, 리프레쉬와 재요청은 미들웨어 형식으로 해야한다.
    }

    // 리프레쉬 토큰 구현 방법
    // 1. 현재 나처럼 폴링을 이용하는 방법
    // 2. 토큰이 필요한 API 요청을 보내기 전에 토큰이 유효한지 확인하고 유효하지 않은 경우 새로 고치는 방법..(즉 1차적으로 클라이언트에서 확인)
    // 3. 이거는, 일단 엑세스 토큰을 보내고, 서버에서 확인해서 아니면, 다시 만료됐다하고, 그걸 만료상태를 받으면, 리프레쉬 토큰으로 요청받은후, (즉 1차적으로 서버에서 확인) 
    // 새 엑세스 토큰으로 api를 재요청하는 방식인데, 문제는 그 api를 어떻게 다시 요청하냐가 관건이다. (axios 설정에서 처리할수도 있을듯한데, 물론 각각 그렇게 할수 있지만, 그건 잘못된 방식)

    // 해결방법
    // 일단은, 공통 함수를 만들고, 요청 주소와 api 옵션을 인수로 넘겨준다. 즉 그 후 401에러일 경우, 리프레쉬를 호출하고, 성공하면, 그 공통함수를 작동시킨다. 
    // 공통함수속에, 리프레쉬 토큰 재호출이 이미 존재해야할듯 하다.
    // api에다. 공통 함수를 넣거나, axios로 설정하거나 해보면 될듯하다... 
    // 즉 axios에도 error.response를 가져올수 있다. 즉 이 상태에서 특정 상태면,  
    // 즉, 다시 재요청 방법은. error.response.config.url과 error.response.config.data등을 이용하는 방법이 있겠다. 추가로 필요에 따라 error.response.config.headers도. 보낸다.
    // 메소드는 error.response.config.method를 통해 보낸다.
    // 즉 리프레쉬 토큰을 성공하면, config에 나타난 정보 그대로 재요청하는 방법이다.
    // 즉, 정리해서, response를 공통 함수에 인수로 그대로 넘겨주기만 하면 된다는것..
    


    // return axiosInstance(originalRequest) 이 부분이, 재요청 부분인듯.
    // if (!originalRequest._retry) originalRequest._retry = true; 이 부분은 임의로 삽입한 부분인듯, 즉 무한 재요청을 방지 목적이거나 그런 목적인듯.. OK 이해됐다..
    // 예제 참조..
    // axiosInstance.interceptors.response.use(
    //   function(response) {
    //     return response;
    //   },
    //   function(error) {
    //     const originalRequest = error.config;
    //     console.log("e");
    //     if (error.code != "ECONNABORTED" && error.response.status === 401) {
    //       if (!originalRequest._retry) {
    //         originalRequest._retry = true;
    //         return axiosInstance
    //           .post("/tokens/auth", {
    //             refreshToken: getRefreshToken(),
    //             grantType: "refresh_token",
    //             clientId : "website"
    //           })
    //           .then(response => {
    //             localStorage.authentication = JSON.stringify(response.data);
    //             updateAuthInstant();
    //             eturn axiosInstance(originalRequest);r
    //           });
    //       } else {
    //         localStorage.removeItem("authentication")
    //         console.log("fafaf")
    //         browserHistory.push({
    //             pathname: '/login',
    //         });
    //       }
        
    //     }
    //     return Promise.reject(error);
    //   }
    // );

    // 단 리프레쉬 토큰과 재요청은 이렇게 하는게 좋지만, 한가지 바꿔야할건
    // 바로 로그인 로그아웃 상태 처리 부분이다..  
    // 즉 현재처럼, 시간으로 처리한다면, 어쩌면, 폴링 방식이 가장 좋을수는 있다..
    // 만약 이런 방식으로 바꾼다면, 리프레쉬 토큰을 기준으로 로그인을 해두되, 
    // 새 엑세스 토큰을 요청했을때, 네트워크 에러가 아닌, 혹은 네트워크 포함 적절한 상태에 따라서, 1~2회 요청하고, 실패시에, 리프레쉬를 삭제해, 로그아웃 하는 방식을 고려해볼수도
    // 아니면 리프레쉬는 그대로 두되, login status를 따로 만들어, 그 상태값을 바꿔주거나... 일단 리프레쉬 토큰은 삭제가 되야할지도.. 
    // 혹은 아무튼 이건 잘 고려해서 만들면 될듯.. 적절하게.. 


    // api호출 퍼센티지
    // api호출에 퍼센트 부분은 이렇게 활용, api호출에 config설정으로 넣어줘야함.. 일단 이건, 업로드용으로 해두긴 했다..
    // fileSubmit: {
    //   headers: { 'Content-Type': 'multipart/form-data' }, 
    //   onUploadProgress: uploadEvent => { console.log('UploadProgress: ' + Math.round(uploadEvent.loaded / uploadEvent.total * 100) + '%') } 
    // }
    // axios.post(`${state.api_url}/postFile`, state.postFile, state.config.fileSubmit).

    // 상태만 필요하면, 이런 형식이면 될듯..
    // export const getPost = (postId) => dispatch => {
    //   dispatch(getPostPending());
    //   return getPostAPI(postId).then((response)=> {
    //       dispatch(getPostSuccess(response))
    //       return response;
    //   }).catch(error=> {
    //       dispatch(getPostFailure(error));
    //       throw(error);
    //   })
    // }


    // 두번 호출 되는 현상은
    // 스위치가 2개로 나눠져있기 떄문이지 않나란 생각도 든다. 한개로만 되있다면?
    // 일단 작업하면서 테스트를 해봐야겠다... 스위치로 하나로 묶어야 되는걸수도 있겠다.. 이게 원인일지도,, 원인이 있을거다.
    // 즉 여러가지 방식으로 해보는거다.. 그래야 답이 나올듯.. 일단 해보는걸로 하자..
    // 아닐수도 있다.. 즉, 다른 방식으로 리액트 라우터를 다시 짜는게 중요할듯 싶다.. 그렇게 해서 테스트를 해보는게 나을지도..
    // 일단 교과서적인 방식등도 참조가 필요할듯 하다..
    

    // node.js는, 일단 지금 너무 지저분해고 재대로 된 느낌이 안드니, 정리해서, 재대로 짜자. 그리고 핵심 필수적인거 숙지하고.
    // 책 참조가 필요할듯 싶다.


  }

  render() {
    // 실제 그 페이지에 가지 않아도, 리다이렉트를 처리 안해도, 라우트에 연결되있으면, 이미 그 안에 라우트는 인식이 되있다란 점이다. 좋네.. 
    // 즉 굳이 리다이렉트해서 갈 필요 없고, 단, 해당 /company만 들어갈떄 리다이렉트를 처리해주면 된다는 점이다.
    // 그리고 추가로 index.js에서 이미 감싸는 것도 처리가 가능하단 점이다. 이 정도면 퍼펙트하네.. 이렇게 하면 되겠군..
    return (
      <Router>
        <GlobalStyles/>
        <GlobalCotainer>   
          <Switch>
            <Route exact path='/' component={IntroPage}/>
            <Route path='/company' component={Company}/>
            <Route path='/cscenter' component={CsCenter}/>
            <Route path='/product' component={Product}/>
            <Route path='/user' component={User}/>
            <Route component={NotFoundPage}/>
          </Switch>
        </GlobalCotainer>
      </Router>
    );
  }
}

export default App


// 앱설계, 글로벌 컨테이너가 있고, 로컬 컨테이너가 있다. 그렇지만, 기본적으로 글로벌이다. 공통이라면..
// 그럼 로컬 영역 설정은 상태값으로 전달해주면 된다. 리덕스라던지..