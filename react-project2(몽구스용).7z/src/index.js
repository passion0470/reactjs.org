import React from 'react';
import ReactDOM from 'react-dom';
import App from './App';
import { Provider } from 'react-redux'
import store from './stores'

ReactDOM.render(
    <Provider store={store}>
        <App />
    </Provider>,
    document.getElementById('root')
)

// If you want your app to work offline and load faster, you can change
// unregister() to register() below. Note this comes with some pitfalls.
// Learn more about service workers: http://bit.ly/CRA-PWA

// 프리젠테이션 네이밍, Presenter
// 즉 예를들어 navBar라면, 마크업 최상위에선 Navbar를 쓰고, 파일이름은 NavbarPresenter를 쓴다. 