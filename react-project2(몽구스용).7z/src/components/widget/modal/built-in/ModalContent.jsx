import React, {Fragment} from 'react';

export default function ModalContent({title, body, footer, children}) {
    return (
        <Fragment>
        { children ? 
            (<Fragment> {children} </Fragment>) : 
            (<Fragment>
                <header className="modal-header">{title}</header>
                <div className="modal-body">{body}</div>
                <footer className="modal-footer">{footer}</footer>
            </Fragment>)}
        </Fragment>

    )
}

