import React from 'react';
import styled from 'styled-components'
import { ModalContent } from './built-in'
import { CSSTransition } from 'react-transition-group';

const Modal = styled.nav`
    transition-duration: 0.5s; text-align: initial; z-index:9998;
    .modal { 
        &, &-mask { width: 100%; height: 100%; position: fixed; top: 0; left: 0; }
        &-mask { background-color: rgba(0, 0, 0, .5); z-index: 9998; }
        &-area { width:300px; background: #fff; padding:15px; box-sizing:border-box; z-index: 9998; position: fixed; left:50%; top:50%; transform:translate(-50%, -50%);}
        &-close-button {background: transparent; position: absolute; top:-35px; right:-15px;}
    }
`;

const ModalMask = ({id, status, onModalClose}) => {
    return(
        <CSSTransition in={status === id} classNames="fade" timeout={500} unmountOnExit>
            <div className="modal-mask" onClick={onModalClose}></div>
        </CSSTransition>
    )
}

const ModalArea = ({id, status, children, onModalClose}) => {
    return(
        <CSSTransition in={status === id} classNames="fade" timeout={500} unmountOnExit>
            <section className="modal-area">
                <button className="modal-close-button" onClick={onModalClose}></button>
                {children}
            </section>
        </CSSTransition>
    )
}

export default function ModalPresenter({id, status, title, body, footer, onModalShow, children}) {
      return (
        <Modal className="modal-wrapper">
            <ModalMask id={id} status={status} onModalClose={() => onModalShow(0)}/>
            <ModalArea id={id} status={status} onModalClose={() => onModalShow(0)}>
                <ModalContent title={title} body={body} footer={footer} children={children} />
            </ModalArea>
        </Modal>
    )
}