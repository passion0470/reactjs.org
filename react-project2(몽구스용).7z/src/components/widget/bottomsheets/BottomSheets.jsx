import React, { Fragment } from 'react';
import styled from 'styled-components'

const Wrapper = styled.div`
.bottom-sheets-wrapper { 
    width:300px; background: #fff; padding:15px; box-sizing:border-box; z-index: 9998; 
    position: fixed; left:50%; bottom:0; 
    transform:translateX(-50%); 
    border: 1px solid #666; 
    &.active {animation-duration: 1s; animation-name: slidein; }
    &.deactive {animation-duration: 1s; animation-name: slideinBot;}
}

.slide {
    &-enter-active { transition: 700ms ease-out; overflow: hidden; }
    &-enter, &-leave-active, &-leave-to  { transition: 700ms ease-out; }
}

@keyframes slidein {
  from {margin-bottom: -400px;} to {margin-bottom: 0;}
}

@keyframes slideinBot {
  from {margin-bottom: 0;} to { margin-bottom: -400px;}
}
`;

export default function BottomSheets({children, header, body, footer, status, wSize}) {
    return (
        <Wrapper className="bottom-sheets">
            {/* <section className={cx('bottom-sheets-container', {active: this.props.status}, {deactive: !this.props.status})} style={{ width: this.props.wSize }}> */}
            <div className={'bottom-sheets-wrapper' + status ? ' active' : ' deactive'} style={{ width: wSize }}>
                {children ? children : 
                    <Fragment>
                        <header className="bottom-sheets-header">{header}</header>
                        <div className="bottom-sheets-body">{body}</div>
                        <footer className="bottom-sheets-footer">{footer}</footer>
                    </Fragment>}
            </div>
        </Wrapper>
  )
}

