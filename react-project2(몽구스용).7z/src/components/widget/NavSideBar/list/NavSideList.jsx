import React from 'react';

const NavSideList = ({children}) => {
    return (
        <ul className="nav-list depth-primary">
            {children}                
        </ul>
    )
}

export default NavSideList
