import React, { Fragment } from 'react';
import { NavLink } from 'react-router-dom';
import { CSSTransition } from 'react-transition-group';


const NavSideSecondItem = ({item}) => {
    return (
        <Fragment>
            {item.get('children') && item.get('children').valueSeq().toArray().map((secDepItem, index) => 
                <li key={index} className="nav-item">
                    <NavLink to={secDepItem.get('path')}> {secDepItem.get('title')} </NavLink>
                </li>)}
        </Fragment>
    )
}

const NavSideSecondList = ({children}) => {
    return (
        <ul className="nav-list depth-second">
            {children}
        </ul>
    )
}

const NavSideItem = ({id, list, status, onShowControl, onEnter, onExit}) => {
    return (
        <Fragment>
            {list.getIn([id, 'children']) && list.getIn([id, 'children']).valueSeq().toArray().map((item, index) => 
                <li key={index} className="nav-item" onClick={() => onShowControl(index)}> {item.get('title')} 
                    <CSSTransition in={status.getIn(['show', 1]) === index} unmountOnExit classNames="slide" timeout={500} onEnter={(e)=> onExit(e)} onEntering={(e) => onEnter(e)} onExiting={(e)=> onExit(e)}>
                        <NavSideSecondList>
                            <NavSideSecondItem item={item} />
                        </NavSideSecondList>
                    </CSSTransition> 
                </li>)}
        </Fragment>  
    )
}

export default NavSideItem
