import React from 'react'
import styled from 'styled-components'
import { NavSideList, NavSideItem } from './'

const NavSideBar = styled.nav`
    .nav-list.depth-second { width:100%;  background: #ccc; overflow: hidden; }
`;

export default function NavSideBarPresenter({id, list, status, onShowControl, onEnter, onExit}) {
  return (
    <NavSideBar id="local-side-navbar">
        <NavSideList>
            <NavSideItem id={id} list={list} status={status} onShowControl={onShowControl} onEnter={onEnter} onExit={onExit} />
        </NavSideList>
    </NavSideBar>
  )
}
