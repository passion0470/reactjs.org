import React from 'react';
import styled from 'styled-components'
import Tab from './Tab';

const TabWapper = styled.div`
    .tab-list { border-bottom: 1px solid #ccc; padding-left: 0; }
    .tab-item { display: inline-block; list-style: none; margin-bottom: -1px; padding: 0.5rem 0.75rem; }
    .is-active { background-color: white; border: solid #ccc; border-width: 1px 1px 0 1px; }
`;

export default function Tabs({children, activeTab, onClickTabItem}) {
    return(
    <TabWapper className="tabs">
        <ul className="tab-list">
          {children.map((child, index) => {
            return <Tab activeTab={activeTab} key={index} label={child.props.label} convert={child.props.convert} onClickTabItem={onClickTabItem} />})}
        </ul>
        <div className="tab-content">  
          {children.map((child) => child.props.label === activeTab && child.props.children )}
        </div>
    </TabWapper>
    )
}