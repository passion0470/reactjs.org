export { default as Tabs } from './Tabs'
export { default as Tab } from './Tab'