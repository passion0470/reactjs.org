import React from 'react';
import PropTypes from 'prop-types';

const Tab = ({activeTab, label, convert, onClickTabItem}) => {
    // let className = 'tab-item'; if(activeTab === label) className += ' is-active';
    // let className = activeTab === label ? ['tab-item', 'is-active'].join(' ') : 'tab-item'
    // let className = ['tab-item', activeTab === label && 'is-active'].join(' ')
    // let className = ['tab-item'].concat(activeTab === label && 'is-active').filter(x => x).join(' ')
    // let className = ['tab-item', activeTab === label && 'is-active'].filter(isNaN).join(' ')
    // let className = ['tab-item', activeTab === label && 'is-active'].filter(x => x).join(' ')
    // let className = 'tab-item' + [activeTab === label && ' is-active'].filter(x => x)
    let className = 'tab-item' + (activeTab === label ? ' is-active': '')

    return(
    <li className={className} onClick={() => onClickTabItem(label)}>
        {convert ? convert : label}
    </li>
    )
}

Tab.propTypes = {
    activeTab: PropTypes.string.isRequired,
    label: PropTypes.string.isRequired,
    onClickTabItem: PropTypes.func.isRequired,
}

export default Tab