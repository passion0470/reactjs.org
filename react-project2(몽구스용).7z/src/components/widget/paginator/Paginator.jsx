import React from 'react';
import styled from 'styled-components'

const Wapper = styled.nav`
    border: 1px solid #dadada; display: inline-flex;
    .paginate-list, .paginate-item { display: inline-flex; justify-content: center; }
    .paginate-item { width:30px; height:30px; line-height:30px; text-align: center; box-sizing: border-box; font-size:12px; cursor: pointer; border-right: 1px solid #dadada; 
        &:last-of-type {border-right: 0;} 
        & > a { padding:4px 8px; display: block; width:100%; height:100%; }


        &.is-active { background: #5881cc; color:#fff;
            & >  * { color:#fff }
        }
        &:hover {background: #5881cc; color:#fff;
            & >  * { color:#fff }
        }
    }
`;

function Paginator({page, totalPage, onCurrentPage, onSkipPrevPage, onSkipNextPage, onIncrementPage, onDecrementPage}) {
    return (
        <Wapper id="paginator-container">
            <ul className="paginate-list">
                <li className="paginate-item paginate-prev-first" onClick={() => onCurrentPage(1)}>{"<<"}</li>
                <li className="paginate-item paginate-prev" onClick={() => onDecrementPage()}>{"<"}</li>
                <li className="paginate-item paginate-prev-skip" onClick={() => onSkipPrevPage()}>{".."}</li>
                {/* {new Array(totalPage).fill(0).map((item, index) => 
                <li key={index} className="paginate-item">
                    <NavLink to="#">{index+1}</NavLink>
                </li>)} */}
            </ul>
            <ol className="paginate-list">
                {page.list.map((item) => 
                <li key={item} className={'paginate-item' + (page.current === item ? ' is-active': '')} onClick={() => onCurrentPage(Number(item))}>
                    {item}
                    {/* <NavLink to={{pathname: '/cscenter/board', search: `?id=${id}&page=${item}`}} activeClassName="is-active">{item}</NavLink> */}
                </li>)}
            </ol>
            <ul className="paginate-list">
                <li className="paginate-item paginate-next-skip" onClick={() => onSkipNextPage()}>{".."}</li>
                <li className="paginate-item paginate-next" onClick={() => onIncrementPage()}>{">"}</li>
                <li className="paginate-item paginate-next-last" onClick={() => onCurrentPage(totalPage)}>{">>"}</li>
            </ul>
        </Wapper>
    )
}

export default Paginator;
