import React, { Fragment } from 'react';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import { NavLink } from 'react-router-dom';

export default function ToolItem({list, onSignedIn, onSignOut}) {
    // const handleSignIn = () => {
    //     return onSignedIn ? 'auth' : 'unauth' 
    // }
 
    return (
        <Fragment>
            {/* {list.get(handleSignIn()).valueSeq().toArray().map((item, index) =>    */}
            {/* {list.get(onSignedIn ? 'auth' : 'unauth').valueSeq().toArray().map((item, index) =>    */}
            {list.valueSeq().toArray().filter(item => onSignedIn ? item.get('auth') : !item.get('auth')).map((item, index) => 
                <li key={index} className="tool-item">
                {item.get('path') 
                    ? <NavLink to={item.get('path')}><FontAwesomeIcon icon={item.get('icon')} size="lg"/></NavLink> 
                    : <FontAwesomeIcon icon={item.get('icon')} size="lg" onClick={onSignOut}/>}
                </li>)}
            {/* {Object.keys(list.get(handleSignIn()).toJS()).map((key, index) => 
            <li key={index} className="tool-item">
                <NavLink to={list.getIn([handleSignIn(), key, 'path'])}> <FontAwesomeIcon icon={list.getIn([handleSignIn(), key, 'icon'])} size="lg"/> </NavLink>
            </li>)} */}
        </Fragment>
    )
}
