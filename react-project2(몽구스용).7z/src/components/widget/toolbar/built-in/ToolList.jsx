import React from 'react';

const ToolList = ({children}) => {
    return (
        <ul className="tool-list">
            {children}                
        </ul>
    )
}

export default ToolList
