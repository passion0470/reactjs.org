import React from 'react';
import styled from 'styled-components'
import { ToolList, ToolItem } from 'components/widget/toolbar/built-in'

const ToolbarWapper = styled.nav`
    display: flex; justify-content:flex-end; align-items: center;
    ul.tool-list {
        li.tool-item { display: inline-block;
            & > a, & > svg { color:#999; padding:10px; vertical-align:middle;
                &:hover { color:blue; }
            }
        }
    }
`;

function Toolbar({list, onSignedIn, onSignOut}) {
    return (
        <ToolbarWapper id="global-header-toolbar">
            <ToolList>
                <ToolItem list={list} onSignedIn={onSignedIn} onSignOut={onSignOut}/>
            </ToolList>
        </ToolbarWapper>
    )
}

export default Toolbar;

