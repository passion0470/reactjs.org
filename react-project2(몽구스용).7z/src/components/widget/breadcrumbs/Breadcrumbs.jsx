import React, {Fragment} from 'react';
import { Route, Link } from 'react-router-dom';

const BreadcrumbsItem = ({ match }) => (
    <Fragment>
        <li className={'breadcrumb-item' + match.isExact ? ' breadcrumb-active' : undefined}>
            <Link to={match.url || ''}>
                {match.url.substr(match.url.lastIndexOf('/')+1, match.url.length).firstCapitalize()}
                {/* {meta.value} */}
            </Link>
        </li>
        <Route path={match.url + '/:path'} component={BreadcrumbsItem}/>
        {/* <Route path={match.url + '/:path'} render={props => (<BreadcrumbsItem {...props} meta={{value:meta.value}}/>)} /> */}
    </Fragment>
)

export default function Breadcrumbs() {
    return(
    <nav className="breadcrumbs">
        <ul className='breadcrumb-list'>
            <Route path='/:path' component={BreadcrumbsItem}/>
            {/* <Route path='/:path' render={props => (<BreadcrumbsItem {...props} meta={{value:this.props.meta.value}}/>)} /> */}
        </ul>
    </nav>
    )
}