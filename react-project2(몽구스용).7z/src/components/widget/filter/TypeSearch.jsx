import React, { Fragment } from 'react';
// import styled from 'styled-components'

export default function TypeSearch({searchType, value, onValueChange, onSearch}) {
    return (
      <Fragment>
          <select name="type" onChange={(e) => onValueChange(e)} >
            {searchType.map((type, index) => 
              <option key={index} value={type.toLowerCase()}>{type}</option>)}
          </select>
          <input type="text" name="value" value={value} onChange={(e) => onValueChange(e)}/>
          <button onClick={onSearch}>Search</button>
      </Fragment>
  )
}

