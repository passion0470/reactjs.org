import React from 'react';
import styled from 'styled-components'

const Form = styled.form`
    display: inline-block; 
    margin: 0 5px;
`;

export default function Search({stypes, svalue, onValueChange, onSubmit, onReset}) {
    return (
      <Form onSubmit={onSubmit}>
          {stypes && 
          <select name="stype" onChange={(e) => onValueChange(e)} >
            {stypes.map((stype, index) => 
              <option key={index} value={stype.toLowerCase()}>{stype}</option>)}
          </select>}
          <input type="text" name="svalue" value={svalue} onChange={(e) => onValueChange(e)}/>
          <button type="submit">Search</button>
          <button type="button" onClick={onReset}>Reset</button>
      </Form>
  )
}

