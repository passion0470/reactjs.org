import React, { Fragment } from 'react';
import styled from 'styled-components'

const ClientSerach = styled.input`
    display: inline-block; 
    margin: 0 5px;
`;

export default function ClientSerachPresenter({post, svalue, onValueChange, children}) {
    return (
        <Fragment>
            <ClientSerach type="text" name="svalue" value={svalue} onChange={(e) => onValueChange(e)}/>

            {/* post.includes(svalue.toUpperCase()) ? post : false */}

            {children}
            {/* {post.map((item) => post.includes(svalue.toUpperCase()) ? true : false )} */}
        </Fragment>
    )
}

// 실제 작업하면서 하자. 일단 감이 잘 안잡히네..

// 클라이언트 서치 리액트로 검색해서, 예제를 보고 만들자.

// 고민해보니 필터를 쓰면 되겠다. 해당 값에 대해.. 근데. 그 값을 전달하는 부분이 필요하다... 리덕스를 써야하나?
// 여러군대 사용하는걸 감안해서, 컨테이너가 필요할수도..그 컨테이너 안에서만 적용되도록..

// <TabWapper className="tabs">
// <ul className="tab-list">
//   {children.map((child, index) => {
//     return <Tab activeTab={activeTab} key={index} label={child.props.label} convert={child.props.convert} onClickTabItem={onClickTabItem} />})}
// </ul>
// <div className="tab-content">  
//   {children.map((child) => child.props.label === activeTab && child.props.children )}
// </div>
// </TabWapper>
