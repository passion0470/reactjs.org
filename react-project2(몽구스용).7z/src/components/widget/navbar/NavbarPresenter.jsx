import React from 'react';
import styled from 'styled-components'
import { NavList, NavItem } from './list'

const Navbar = styled.nav`
    z-index: 9000;     
    .nav-list.depth-primary {
        & > .nav-item { display: inline-block; position: relative; background: #333;
            &:hover { background: #555; transition-duration: 0.2s; }
            & > a { display: block; height:50px; line-height: 50px; padding: 0 10px; color:white; transition-duration: 0.2s;
                &:hover { background: #555; transition-duration: 0.2s; }
                &.is-active { background: #3c32cc; transition-duration: 0.2s; }
            }
        }
    }
    .nav-list.depth-second { position: absolute;
        & > .nav-item { 
            & > a { display:block; width: 100px; padding: 5px 10px 5px 10px; background: #333; color:white;
                &:hover { background: #555; }
                &.is-active { background: #3c32cc; }
            }
        }
    }
`;

function NavbarPresenter({list, show, showControl}) {
    return (
        <Navbar id="global-header-navbar">
            <NavList>                
                {/* {this.props.list.valueSeq().toArray().map((item, index) => 
                <NavItem key={index} item={item} onClick={() => this.showControl(index)} onMouseOver={() => this.showControl(index)} onMouseOut={() => this.showControl(null)} onMouseUp={() => this.showControl(null)}> 
                    <NavD2List show={this.props.state.getIn(['show', 0])} index={index} item={item}>
                        {item.get('depth2') && item.get('depth2').valueSeq().toArray().map((item, index) => 
                        <NavD2Item key={index} item={item}/>)}
                    </NavD2List>
                </NavItem>)} */}
                <NavItem list={list} showControl={showControl} show={show}/>  
            </NavList>
        </Navbar>
    )
}

export default NavbarPresenter


// 순수 컴포넌트, 프리젠테이션 컴포넌트, 컨테이너 컴포넌트로 나누자.. 순수 컴포넌트는 기존 빌트인이고, 순수하기에 따로 명칭을 안붙이고, 나머지는 붙인다.
// 나머지 컨테이너가 안들어간 순수 컴포넌트를 쓸땐, 프리젠터를 안붙여도 될듯하다.. 단 폴더명은 그 컴포넌트 대표성이기에, 대문자로 해야할듯.. 그럼 패키지가 안들어가네
// 그냥 프리젠터를 붙일가. 고민이네.. 아님 순수 컴포넌트는 패키지를 붙일까, 아님 모든 컴포넌트 대표성은 패키지를 붙일까 고민..
// 솔직히 그냥 다 붙이는게 나을듯 하다.. 모든걸 하나의 묶음이란 의미로..


// 네브바는 헤더폴더와 사이드폴더를 두고, 나누기와, SideNavBarPresentor.jsx / NavBarPresenter.jsx로 나눠, 없는건 헤더의 기본형으로 아니면 다른 방식 고민..
// NavSideBarPresentor / NavHeaderBarPresentor.jsx