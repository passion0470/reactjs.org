import React from 'react';

const NavList = ({children}) => {
    return (
        <ul className="nav-list depth-primary">
            {children}                
        </ul>
    )
}

export default NavList
