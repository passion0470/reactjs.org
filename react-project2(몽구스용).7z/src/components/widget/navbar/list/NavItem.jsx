import React, { Fragment } from 'react';
import { NavLink, Link, withRouter } from 'react-router-dom';
import { CSSTransition } from 'react-transition-group';
// import { toJS } from 'immutable';

// const NavItem = ({item, children, onClick, onMouseOver, onMouseOut, onMouseUp}) => {
//     return (
//         <li className="nav-item" onClick={onClick} onMouseOver={onMouseOver} onMouseOut={onMouseOut} onMouseUp={onMouseUp}>
//             <NavLink to={item.get('route')} exact={item.get('exact')} activeClassName="is-active"> {item.get('name')} </NavLink> 
//             {children}  
//         </li>
//     )
// }

const NavD2Item = ({item}) => {
    return (
        <li className="nav-item"> 
            {/* <NavLink to={item.get('path')} activeClassName="is-active"> {item.get('title')} </NavLink>  */}
            <NavLink to={item.get('initPath') ? item.get('initPath') : item.get('path')} activeClassName="is-active"> {item.get('title')} </NavLink> 
        </li>
    )
}

const NavD2List = ({show, index, children}) => {
    return (
        <CSSTransition in={show === index} classNames="fade" timeout={500} unmountOnExit>
            <ul className="nav-list depth-second">
                {children} 
            </ul>
        </CSSTransition> 
    )
}

function NavItem({list, show, showControl, location}) {
    const handleShow = (val) => {
        // console.log(val)
        showControl(val);
    }
    return (
        <Fragment>
            {list.valueSeq().toArray().map((item, index) => 
            <li key={index} className="nav-item" onClick={() => handleShow(index)} onMouseOver={() => handleShow(index)} onMouseOut={() => handleShow(null)} onMouseUp={() => handleShow(null)}>
                {/* <NavLink to={item.get('initPath') ? item.get('initPath') : item.get('path')} exact={item.get('exact')} activeClassName="is-active" className={location.pathname.split('/')[1] === item.get('path') ? "is-active" : ''}> {item.get('title')} </NavLink>  */}
                <Link to={item.get('initPath') ? item.get('initPath') : item.get('path')} className={location.pathname.split('/')[1] === item.get('path').split('/')[1] ? "is-active" : ''}> {item.get('title')} </Link> 
                <NavD2List show={show} index={index}>
                    {item.get('children') && item.get('children').valueSeq().toArray().map((item, index) => 
                    <NavD2Item key={index} item={item}/>)}
                </NavD2List>
            </li>)}

            {/* {Object.keys(list.toJS()).map((key, index) =>  */}
            {/* {list.keySeq().toArray().map((key, index) => 
                <li key={index} className="nav-item" onClick={() => handleShow(index)} onMouseOver={() => handleShow(index)} onMouseOut={() => handleShow(null)} onMouseUp={() => handleShow(null)}>
                 <NavLink to={list.getIn([key, 'initPath']) ? list.getIn([key, 'initPath']) : list.getIn([key, 'path'])} exact={list.getIn([key, 'exact'])} activeClassName="is-active"> {list.getIn([key, 'title'])} </NavLink> 
                <NavD2List show={show} index={index}>
                    {list.getIn([key, 'children']) && list.getIn([key, 'children']).map((secondkey, index) => 
                        <NavD2Item key={index} item={list.getIn([key, 'children', secondkey])}/>)}
                </NavD2List> 
            </li>)} */}
        </Fragment>
    )
}

export default withRouter(NavItem)