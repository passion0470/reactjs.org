import React from 'react';
import styled from 'styled-components'
import PostList from './PostList'
import PostItem from './PostItem'
import PaginatorContainer from 'containers/widget/paginator/PaginatorContainer'
import SearchContainer from 'containers/widget/filter/SearchContainer'

const List = styled.section`

`;

const ListWrapHeader = ({children, onActiveEdit}) => {
    const title = <h3>Free Board</h3>
    const subTitle = <small>Please fill in this form to create an account</small>
    return (
        <header className="list-wrap-header">
            {title} {subTitle}
            {children}
            <button type="button" name="post.write" onClick={onActiveEdit}>Write</button>
        </header>
    )
}

export default function ListPresenter({ id, titles, csizes, stypes, posts, status, onGetPosts, onActiveEdit, onToPost, onContainerBranch }) {
    return (
      <List className="post-list-warpper">
          <ListWrapHeader onActiveEdit={onActiveEdit} >
            <SearchContainer id={id} stypes={stypes} onGetPosts={onGetPosts}/>
          </ListWrapHeader>
          <div className="list-wrap-body">
            <PostList titles={titles} csizes={csizes} >
              {posts.map((post, index) => 
                <PostItem key={index} post={post} onToPost={onToPost} /> )}
            </PostList>
          </div>
          <footer className="list-wrap-footer">
            <PaginatorContainer id={id} totalPage={status.get('totalPage')} onGetPosts={onGetPosts} />
          </footer>
      </List>
  )
}
