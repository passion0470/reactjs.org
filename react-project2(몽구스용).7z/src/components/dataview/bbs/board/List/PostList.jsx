import React from 'react'

export default function PostList({titles, csizes, children}) {
  return (
    <table className="post-list tb-1">
        <colgroup>
          {csizes.map((csize, index) => <col key={index} width={csize} />)}
        </colgroup>
        <thead>
          <tr>{titles.map((title, index) => <th key={index}>{title}</th>)}</tr>
        </thead>
        <tbody>
          {children}
        </tbody>
    </table>
  )
}
