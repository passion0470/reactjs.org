import React from 'react'
import { Link } from 'react-router-dom';

export default function PostItem({post, onToPost}) {
  return (
    <tr className="post-item">
      <td>{post.get('_id')}</td>
      <td style={{textAlign:'left'}}> 
        <Link to={onToPost(post.get('_id'))}>{post.get('title')}</Link>
      </td>
      <td>{post.getIn(['author', 'name'])}</td>
      <td>{post.get('file_cnt')}</td>
      <td>{post.get('replie_cnt') && post.get('replie_cnt')}</td>
      <td>{post.get('recommend')}</td>
      <td>{post.get('hits')}</td>
      <td>{post.get('date')}</td>
    </tr>
  )
}

