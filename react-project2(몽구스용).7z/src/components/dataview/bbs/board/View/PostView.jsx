import React, { useEffect } from 'react';
import styled from 'styled-components'

const Article = styled.article`
    width:100%; height:500px; border: 1px solid #ddd;
    header.post-view-header { display: flex; 
        & > * { display: inline-block; }
        .post-view-primary { width: 80%;
            h5 { font-size:20px; } 
            .post-view-author { font-size:13px; color:#888; }
        }
        .post-view-info { width: 20%; text-align: right;
            .post-view-date { }
            .post-view-liked { }
            .post-view-hits { }
        }
    }
    div.post-view-body {
        width:100%; height:350px;
    }
    footer.post-view-footer {
        .post-view-tags { width:100; height:30px; background: #ddd; }
        form.post-view-form { display: flex; 
            & > fieldset { flex-basis:0; flex-grow:1; }
            fieldset.post-helper-fieldset {

            }
            fieldset.post-control-fieldset { 
                & > * { float:right; }
            }
        }
    }
    .file { cursor: pointer; 
        &:hover { color: #4267b2 }  
    }
`;

// 기본적인 타이틀과 날짜와 작성자
const PostViewHeader = ({post}) => {
    return(
        <header className="post-view-header">
            <div className="post-view-primary">
                <h5 className="post-view-title">{post.get('title')}</h5>
                <span className="post-view-author">{post.getIn(['author', 'email'])}</span>
            </div>
            <div className="post-view-info">
                <div className="post-view-date">{post.get('date')}</div>
                <span className="post-view-liked"> liked Icon: 3</span>
                <span className="post-view-hits"> hits Icon: 20</span>
            </div>
        </header>
    )
}

const PostViewBody = ({post}) => {
    return(
        <div className="post-view-body">
            {post.get('body')}
        </div>
    )
}

const PostViewFooter = ({postId, files, onToList, onActiveEdit, onDeletePost, onReadFile, onDeleteFile, onModifyFile}) => {
    return(
        <footer className="post-view-footer">
            <div className="post-view-tags"></div>
            <form className="post-view-form">
                <fieldset className="post-helper-fieldset">
                    <input type="button" value="Liked" />
                </fieldset>
                <fieldset className="post-control-fieldset">
                    <input type="button" name="post.modify" value="Modify" onClick={(e) => onActiveEdit(e, postId)} /*  onClick={() => onEditPost(1)} */ />
                    <input type="button" value="Delete" onClick={onDeletePost} />
                    <input type="button" value="List" onClick={onToList} />
                </fieldset>
           </form>
           {files && files.map((file, index) => 
            <div>
                <span key={index} className="file" onClick={() => onReadFile(file.get('_id'), file.get('name'), file.get('type'))}>{index+1}. {file.get('name')}</span>
                <input type="button" value="Modify" onClick={() => onModifyFile(file.get('_id'))}/>
                <input type="button" value="Delete" onClick={() => onDeleteFile(file.get('_id'))} />
            </div>
            )}


            {/* 쓰기는 리스트 쪽에? 고민 필요, 본문에 에디트는 수정 역활만? 그게 맞을수도.. */}
            {/* 즉 오로지 뷰에 충실한, 좋아요 버튼과 목록, 글쓰기, 수정, 삭제등. 추가로 태그 */}
            {/* 푸터에 리플라이 쓰는 영역과, 글쓰기, 목록, 좋아요 누르는걸 통합해서 보여주는 형식, 제로보드 참조
            그리고 그 밑에 리플라이 리스트가 뜨는 형식, 
            근데 문제는, 리플라이도 읽고 난후에, 써야할수도 있으니, 고민 필요.
            즉, 혹은, 리플라이를 따로 구별하되, 쓰는 영역은 위든 아래든, 알아서 결정
            단, 포스트 뷰 하단은, 좋아요와 목록 보기를 기본으로 두고, 글쓰기와 수정, 삭제등도 할수 있는 형식.. 
            하위는 작성자글과, 추천글과 최신순 정렬등, 전체가 아닌. 일부 목록만?
            */}
        </footer>
    )
}

export default function PostView({post, files, onInitPost, onToList, onActiveEdit, onDeletePost, onReadFile, onDeleteFile, onModifyFile}) {
    useEffect(() => {    
        window.addEventListener('onInitPost', onInitPost())
        return () => {
            window.removeEventListener('onInitPost', onInitPost())
        }
    }, [])
      
    return (
    <Article className="post-view">
        <PostViewHeader post={post} />
        <PostViewBody post={post} />
        <PostViewFooter files={files} postId={post.get('_id')} onToList={onToList} onActiveEdit={onActiveEdit} onDeletePost={onDeletePost} onReadFile={onReadFile} onDeleteFile={onDeleteFile} onModifyFile={onModifyFile} />
    </Article>
  )
}
// 넘겨야할값이 한개라면, 반드시 필요한값만 넘겨주자.
