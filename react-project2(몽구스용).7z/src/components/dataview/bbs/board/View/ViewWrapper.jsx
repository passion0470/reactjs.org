import React, { Fragment } from 'react';
import PostView from './PostView'
// import ReplyContainer from 'containers/dataview/bbs/board/reply/ReplyContainer'

export default function ViewWrapper({post, replyContainer, onInitPost, onToList, onContainerBranch, onActiveEdit, onDeletePost}) {
    return (
    <Fragment>
        {!!onContainerBranch('post') && 
        <div className="view-wrapper">
            <header className="view-wrap-header"></header>
            <div className="view-wrap-body">
                <PostView post={post} onToList={onToList} onInitPost={onInitPost} onActiveEdit={onActiveEdit} onDeletePost={onDeletePost} />
            </div>
            <footer className="view-wrapfooter">
                {replyContainer}
                {/* <ReplyContainer /> */}
            </footer>
        </div>}
    </Fragment>
  )
}
