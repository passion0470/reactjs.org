import React, { Fragment } from 'react';
import PostView from './PostView'
// import ReplyContainer from 'containers/dataview/bbs/board/reply/ReplyContainer'

export default function ViewPresenter({post, files, onReadFile, onDeleteFile, replyContainer, onInitPost, onToList, onContainerBranch, onActiveEdit, onDeletePost, onModifyFile}) {
    return (
    <Fragment>
        {!!onContainerBranch('post') && 
        <div className="view-wrapper">
            <header className="view-wrap-header"></header>
            <div className="view-wrap-body">
                <PostView post={post} files={files} onReadFile={onReadFile} onToList={onToList} onInitPost={onInitPost} onActiveEdit={onActiveEdit} onDeletePost={onDeletePost} onDeleteFile={onDeleteFile} onModifyFile={onModifyFile}  />
            </div>
            <footer className="view-wrapfooter">
                {replyContainer}
                {/* <ReplyContainer /> */}
            </footer>
        </div>}
    </Fragment>
  )
}

// 대문자 폴더 기준은 프리젠터가 있는 폴더를 기준으로 하자.
// PostViewPresentor로 할수도 있다. 근데 폴더명이랑 고려하면 뷰프리젠터가 나을듯..