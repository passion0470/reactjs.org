import React, {Fragment} from 'react';
import styled from 'styled-components'
import { CSSTransition } from 'react-transition-group';
import PostEdit from './PostEdit'

const Wrapper = styled.div`
    width:1300px; height:300px; background: #fff; padding:15px; box-sizing:border-box; z-index: 9998; 
    position: fixed; left:50%; bottom:0; 
    transform:translateX(-50%); 
    border: 1px solid #666; 
`;

export default function EditWrapper({status, post, onSubmit, onChangeInput, onActiveEdit}) {
    return (
    <Fragment>
        <CSSTransition in={status.get('isEdit')} classNames="slideMove" timeout={500} unmountOnExit>
            <Wrapper>
                <header className="post-edit-header"></header>
                <div className="post-edit-body">
                    <PostEdit post={post} status={status} onChangeInput={onChangeInput} onSubmit={onSubmit} onActiveEdit={onActiveEdit} />
                </div>
                <footer className="post-edit-footer"></footer>
            </Wrapper>
        </CSSTransition>
    </Fragment>
  )
}