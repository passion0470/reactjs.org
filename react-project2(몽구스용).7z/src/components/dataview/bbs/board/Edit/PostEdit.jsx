import React from 'react';
import styled from 'styled-components'

const Form = styled.form`
    border: 1px solid #666;
`;

export default function PostEdit({post, onSubmit, onChangeInput, onActiveEdit, onChangeFile}) {
    // 여기서 일단 한차례 분기처리가 필요. 핵심은 post인지, reply인지 여부다.
    // 분기처리는 뭘로 할까? 에디터 타입을 읽고 체크해야할듯..
    // 분기처리 로직은.. 어차피 바디는 공통이고, 
    const taStyle = {width:'100%', height:'200px'}
    return (
    <Form onSubmit={onSubmit}>
        <header className="post-edit-header">
          <input type="text" name="post.title" value={post.title} onChange={(e) => onChangeInput(e)} />
        </header>
        <div className="post-edit-body">
          <textarea name="post.body" style={taStyle} value={post.body} onChange={(e) => onChangeInput(e)} />
          {/* <input type="file" name="files.file1"  onChange={e => onChangeFile(e)} />
          <input type="file" name="files.file2" onChange={e => onChangeFile(e)} />
          <input type="file" name="files.file3" onChange={e => onChangeFile(e)} /> */}
          {/* {new Array(3).fill(0).map((item, index) => 
            <input key={index} index={index} type="file" name={`files[${index}]`} onChange={e => onChangeFile(e)} />)}  */}
          <input type="file" name="files" onChange={e => onChangeFile(e)} multiple />
        </div>
        <footer className="post-edit-footer">
          <button type="submit">Submit</button>
          <button type="button" name="cancel" onClick={(e) => onActiveEdit(e)}>Cancel</button>
        </footer>
    </Form>
  )
}

