import React from 'react';

export default function ReplyEdit({write, modify, reply, onInputChange, onSubmit}) {
    const textAreaStyle = {width:'100%', height:"50px"}
    return (
    <form className="reply-edit-form" onSubmit={(e) => onSubmit(e, reply ? reply.get('_id') : undefined)}>
        <textarea name={write ? 'write.body' : 'modify.body'} style={textAreaStyle} value={write ? write.body : modify.body} onChange={(e) => onInputChange(e)} />
        <button type="submit">Submit</button>
    </form>
  )
}
