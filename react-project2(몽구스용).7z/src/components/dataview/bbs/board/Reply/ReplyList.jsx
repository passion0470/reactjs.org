import React, { useEffect } from 'react';

export default function ReplyList({children, onInitReplys}) {
    useEffect(() => {    
      window.addEventListener('onInitReplys', onInitReplys())
      return () => {
          window.removeEventListener('onInitReplys', onInitReplys())
      }
    }, [])

    return (
    <div className="reply-list">
      <header className="reply-list-header"></header>
      <div className="reply-list-body">
        {children}
      </div>
      <footer className="reply-list-footer"></footer>
    </div>
  )
}

