import React from 'react';
import ReplyList from './ReplyList'
import ReplyEdit from './ReplyEdit'
import ReplyItem from './ReplyItem'

export default function ReplyWrapper({replys, modify, write, status, onInputChange, onSubmit, onModifyCheck, onInitReplys}) {
    return (
    <div className="reply-wrapper">
        <header className="reply-wrap-header">
            리플라이 헤더
        </header>
        <div className="reply-wrap-body">
            <ReplyList onInitReplys={onInitReplys}>
                {replys.map((reply, index) => 
                <ReplyItem key={reply.get('_id')} replyIndex={index} reply={reply} status={status} onModifyCheck={onModifyCheck} 
                    replyEdit={<ReplyEdit reply={reply} modify={modify} onInputChange={onInputChange} onSubmit={onSubmit} />}
                />)}
            </ReplyList>
        </div>
        <footer className="reply-wrap-footer">
            <ReplyEdit write={write} onInputChange={onInputChange} onSubmit={onSubmit} />
        </footer>
    </div>
  )
}

// 여기 푸터에는 답글쓰기를 넣고, 리스트에는 쓰기 수정 버튼, 아이템에는 해당 내용을 넣는 부분? 즉 데이트나 그런 내용들..
// 