import React, { Fragment } from 'react';

export default function ReplyItem({reply, status, replyIndex, onModifyCheck, replyEdit}) {
    return (
    <div className="reply-item">
        <header className="reply-item-header">{reply.get('_id') + reply.getIn(['author', 'email'])}</header>
        <div className="reply-item-body">
            {reply.get('_id') === status.isEdit 
                ? replyEdit
                : reply.get('body') + reply.get('date')}
        </div>
        <footer className="reply-item-footer">
            {reply.get('_id') === status.isEdit 
                ? <button type="button" name="cancel" onClick={() => onModifyCheck(0)}>Cencel</button>
                : <Fragment>
                    <button type="button" onClick={() => onModifyCheck(reply.get('_id'), replyIndex)}>Mofity</button> 
                    <button type="button" name="cancel">Delete</button>
                  </Fragment>}
        </footer>
    </div>
  )
}
