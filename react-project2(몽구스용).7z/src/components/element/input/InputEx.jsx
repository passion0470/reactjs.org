import React, { useState } from 'react';
import InputContainer from 'containers/element/input/InputContainer'

export default function InputEx() {
    // const [email, setEmail] = useState('');

    // 이메일 패턴
    const emailPat = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$/
    // ASCII 문자 이외 전부
    const asciiFilter = /[^\u0020-\u007e]+/g
    return (
        // <form>
        //     <InputContainer pattern={emailPat} filter={asciiFilter} />
        //     <InputContainer />
        // </form>

    <form onSubmit={doSubmit}>
        <FormInput name='email' label='메일 주소'
          value={this.state.email}
          filter={asciiFilter}
          pattern={emailPat}
          onChange={doChange} />
        <FormInput name='tel' label='전화 번호'
          value={this.state.tel}
          filter={/[^0-9-()+]/g}
          pattern={/^[0-9-()+]+$/}
          onChange={doChange} />
        <input type='submit' value='전송'
          disabled={!this.state.allok} />
      </form>
    );
};

