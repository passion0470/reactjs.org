import React from 'react'
import { Link } from 'react-router-dom'

const Button = ({children, ...rest}) => <button {...rest}>{children}</button>

export default function ButtonPresenter({children, to, onClick, disabled, isActive, type, theme='default'}) {
    const ElButton = (to && !disabled) ? Link : Button
    return (
        <ElButton
          to={to} 
          type={to ? false : type === "submit" ? "submit" : "button"}
          className={['button', theme, disabled && 'is-disabled', isActive && 'is-active'].filter(c => c).join(' ')} 
          onClick={to || disabled || type === "submit" ? () => null : onClick}>   
          {children}
        </ElButton>
    )
}

// 링크로 바꿔버리니. 적용이 이미 안된걸수도 있겠다. 링크라면.