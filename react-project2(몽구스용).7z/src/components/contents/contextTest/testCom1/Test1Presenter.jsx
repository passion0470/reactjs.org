import React from 'react';
import styled from 'styled-components'
import Test2Presenter from '../testCom2/Test2Presenter'

const Test1 = styled.div`
`;

function Test1Presenter() {
    return (
        <Test1>
            <Test2Presenter/>
        </Test1>
    )
}

export default Test1Presenter