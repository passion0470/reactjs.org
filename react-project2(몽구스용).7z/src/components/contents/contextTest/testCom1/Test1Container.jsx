import React, { Component } from 'react';
import { Context } from 'stores'
import Test1Presenter from './Test1Presenter'

class Test1Container extends Component {
    constructor() {
        super();
        this.state = { msg: "Hello World" }
    }
    render() {
        return (
            <Context.Provider value={this.state}>
                <Test1Presenter/>
            </Context.Provider>
        );
    }
}

// 컨텍스트에 경우는, 해당 컴포넌트가 하위에 들어가야하는 듯하다. 대신 너무 깊어질 경우 이용할수 있을듯하다...
// 거래소라던지 큰 영역에서 일부분 활용 가능할듯..


// 디렉터리 구조를 Test1/Test1Presenter로 바꾸자.
// 컨테이너는 Test1/Test1Container 마찬가지다..

export default Test1Container


// 하위 영역을 바꾸거나, APP.jsx에서 하되, 값 바꿔주는건, 이벤트를 만들어서, 하위에서 이벤트를 받아와서? 처리? 알아보자. 이것도 동영상 더 습득 필요