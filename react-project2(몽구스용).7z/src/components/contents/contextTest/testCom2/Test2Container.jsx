import React, { Component } from 'react';

class Test2Container extends Component {
    render() {
        return (
            <div>
            </div>
        );
    }
}

export default Test2Container