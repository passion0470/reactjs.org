import React from 'react';
import styled from 'styled-components'
import { Context } from 'stores'

const Test2 = styled.div`
`;

function Test2Presenter() {
    return (
        <Test2>
            <Context.Consumer>
                {/* {value =>  JSON.stringify(value.msg)} */}
                {/* {value => value} */}
                {value => value.msg}
            </Context.Consumer>
        </Test2>
    )
}

export default Test2Presenter