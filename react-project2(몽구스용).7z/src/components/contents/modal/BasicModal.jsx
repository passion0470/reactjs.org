import React from 'react';

export const BasicHeader = () => {
    return(
        <div>BasicHeader</div>
    )
}

export const BasicBody = () => {
    return(
        <div>BasicBody</div>
    )
}

export const BasicFooter = () => {
    return(
        <div>BasicFooter</div>
    )
}

// 데이터 바인딩시, 컨테이너의 컨텐츠에서 모달로 가져와서, 한개씩 가져와 처리한다.