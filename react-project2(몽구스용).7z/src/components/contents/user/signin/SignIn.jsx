import React from 'react';
import styled from 'styled-components'
import { SignInFrom } from './built-in'

const Wrapper = styled.div`
/* position: relative; top: 50%; transform: translateY(-50%); */ margin: 0 auto; max-width: 300px; padding:10px; border:1px solid #ddd;
    header.signin-header { height:70px; text-align: center; }
    div.signin-body {
        form.signin-form {
            & > fieldset { margin:5px 0; }
            & > .signin-input { 
                & > input { width:100%; height:35px; margin:5px 0; }
            }
            & > .signin-helper { font-size:12px; display: flex; padding: 3px 0; 
                & > * { flex-basis:0; flex-grow:1; } 
                .signin-solution { display: flex; justify-content:flex-end;
                    & li { display: inline-block;
                        & + li::before { content:'|'; padding:0 5px; color:#ccc;}
                    }
                }
            }
            & > .signin-handle { 
                input, button { width:100%; height:35px; margin:5px 0; }
            }
        }
    } 
    footer.signin-footer { font-size: 10px; text-align: center; }
`;



function SignInHeader() {
    return (
        <header className="signin-header">
            <h3>MEMBER SIGN-IN</h3><small>Members sign in with email and password</small>
        </header>
    );
};

function SignInBody({children}) {
    return (
        <div className="signin-body">
            {children}
        </div>
    );
};

function SignInFooter() {
    return (
        <footer className="signin-footer">
            <span>COPYRIGHT@ 2019 BASIC-PROJECT ALL RIGHTS RESERVED</span>
        </footer>
    );
};

export default function SignIn({email, password, remember, message, onInputChange, /* onKeyPress, */ onSubmit}) {
    const handleInputChange = (e) => {
        const { value, name } = e.target;
        onInputChange({ value, name });
    }

    const handleRemeberToggle = (value, e) => {
        onInputChange({ value:!value, name: e.target.name });
    }

    return (
    <Wrapper id="signin-wrapper">
        <SignInHeader/>
        <SignInBody>
            <SignInFrom email={email} password={password} remember={remember} onSubmit={onSubmit}
            onRemeberToggle={(e) => handleRemeberToggle(remember, e)} onInputChange={handleInputChange} /* onKeyPress={(e) => onKeyPress(e)} *//>
        </SignInBody>
        <SignInFooter/>
    </Wrapper>
    );
};

// index.js는 실제 로직이 들어간 경우로 하고, 그 외 단순히 연결해주는 경우는 package.json이라고 하자. 해당 컴포넌트에 패키지란걸 뜻하고, 실제 로직과 구별된다.
// private은 개인소유, 즉 해당 컴포넌트 사적 소유란 뜻.