import React from 'react';
import { Link } from 'react-router-dom';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'

const SignInHandle = (/* {onSubmit} */) => {
    return(
    <fieldset className="signin-handle">
        <input className="signin-button" type="submit" value="SIGN IN" />
        {/* <input className="signin-button" type="button" value="SIGN IN" onClick={onSubmit}/> */}
    </fieldset>
    )
}

const SignInHelper = ({remember, onRemeberToggle}) => {
    return(
    <fieldset className="signin-helper">
        <label className="signin-remember">
            <div className="checkbox">
                <input className="checkbox-hidden" type="checkbox" name="remember" value={remember} onChange={onRemeberToggle}/><span className="checkbox-shape">
                {remember && <FontAwesomeIcon className="fa-ico" icon="check" size="sm" />}
                </span>
            </div><span>Remember me</span>
        </label>
        <ul className="signin-solution">
            <li><Link to="/user/forgot">FORGOT</Link></li>
            <li><Link to="/user/signup">SIGN-UP</Link></li>
        </ul>
    </fieldset>
    )
}

const SignInInput = ({email, password, onInputChange}) => {
    return(
    <fieldset className="signin-input">
        <input className="signin-text" type="email" placeholder="Email" name="email" value={email} onChange={onInputChange} required autoFocus/>
        <input className="signin-text" type="password" placeholder="Password" name="password" value={password} onChange={onInputChange} required/>
    </fieldset>
    )
}

export default function SignInFrom({email, password, remember, onRemeberToggle, onInputChange, onSubmit}) {
    return (
        <form className="signin-form" onSubmit={onSubmit}>
            <SignInInput email={email} password={password} onInputChange={onInputChange} />
            <SignInHelper remember={remember} onRemeberToggle={onRemeberToggle}/>
            <SignInHandle />
        </form>
    );
};

