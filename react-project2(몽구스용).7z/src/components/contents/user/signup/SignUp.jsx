import React from 'react';
import styled from 'styled-components'
// import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import { SignUpFrom , SignUpInput, SignUpAccept, SignUpHandle} from './built-in'

const SignUpContainer = styled.div`
fieldset {
  legend { text-transform: uppercase; font: {size:14px;} }
}

/* position: relative; top: 50%; transform: translateY(-50%); */
margin: 0 auto; max-width: 360px; padding:10px; border:1px solid #ddd;

    header.signup-header { height:70px; text-align: center; }
    div.signup-body {
      form.signup-form {
        & > *:not(:last-of-type):not(:first-of-type) { margin:10px 0; }
        .signup-input { 
          & ul li { margin:5px 0; display: flex; }
          & input, & select { width: 100%; height:35px; }
          & .input-password {
            & input[type='password'] { flex-basis:0; flex-grow:1; margin:0 2.5px;
              &:not(:first-of-type) { margin-right:0; }
              &:not(:last-of-type) { margin-left:0; }
            }
          }
          & .input-phone { 
            select, input { margin:0 2.5px; }
            select { width:40%;  margin-left:0; }
            input { margin-right:0; }
          }
        }
        .signup-accept { 
          label.signup-accept-check { 
            span { font: { size:12px; } }
          }
        }
        .signup-handle {
          .signup-handle-submit { height:35px; width:100%; margin:5px 0; }
        }
      }
    }
    footer.signup-footer { font: { size:10px } text-align: center;  }
`;


const SignUpHeader = () => {
  const title = <h3>SIGN-UP</h3>
  const subTitle = <small>Please fill in this form to create an account</small>
  return <header className="signup-header">{title}{subTitle}</header>
}

const SignUpBody = ({children}) => (
  <div className="signup-body">{children}</div>
)

const SignUpFooter = () => (
  <footer className="signup-footer"></footer>
)

function SignUp({user, selection, validation, onInputChange, onValidChange, onSubmit}) {
    return (
    <SignUpContainer className="signup-wrapper">
        <SignUpHeader />
        <SignUpBody>
            <SignUpFrom 
              onSubmit={onSubmit}
              inputArea={<SignUpInput user={user} selection={selection} onInputChange={onInputChange} />} 
              acceptArea={<SignUpAccept validation={validation} onValidChange={onValidChange} />} 
              handleArea={<SignUpHandle />} />
        </SignUpBody>
        <SignUpFooter />
    </SignUpContainer>
    )
}

export default SignUp;

// 대표적인 컴포넌트를 감싸는 부분은 SignUp이라고 하되, 그 하위 순수 컴포넌트는 form처럼 소문자로 한다. 
// 순수 컴포넌트는 해당 순수 컴포넌트 명칭으로 하고, 정 할것없을때 빌트인이라고 하되, 가급적 순수컴포넌트 명칭으로 한다. 어차피 하위에 있다는 것만으로도 내장을 뜻한다.
// 프리젠터가 컨테이너와 연결이 안되있는걸 그냥 순수 컴포넌트로 칭해서, 딱히 안넣어도 될듯한다..