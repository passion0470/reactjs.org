import React from 'react';

function SignUpHandle(/* {onHandleSubmit} */) {
    return (
        // <button className="signup-handle-submit" type="button" onClick={onHandleSubmit}>Submit</button>
        <input className="signup-handle-submit" type="submit" value="SIGN UP" />
    );
};

export default SignUpHandle;