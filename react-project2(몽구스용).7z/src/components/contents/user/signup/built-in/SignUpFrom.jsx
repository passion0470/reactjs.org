import React from 'react';

function SignUpFrom({inputArea, acceptArea, handleArea, onSubmit}) {
    return (
        <form className="signup-form" onSubmit={onSubmit}>
            <fieldset className="signup-input">
                <legend>Enter User Information</legend>
                {inputArea}
            </fieldset>
            <fieldset className="signup-accept">
                <legend>Accept Terms</legend>
                {acceptArea}
            </fieldset>
            <fieldset className="signup-handle">
                {handleArea}
            </fieldset>
        </form>
    );
};

export default SignUpFrom;