import React from 'react';

const SignUpInputItem = ({type, value, onInputChange, placeholder, name, itemClass, convert, children, ...rest}) => {
    const handleInputChange = (e) => {
        const { value, name } = e.target;
        onInputChange({ value, name });
    }
    return (
        // <li className={`signup-input-item ${itemClass ? itemClass : ''}`}>
        // <li className={"signup-input-item" + (itemClass ? ' '+itemClass : '')}>
        // <li className={itemClass ? 'signup-input-item '+itemClass : 'signup-input-item'}>
        // <li className={itemClass ? ['signup-input-item', itemClass].join(' ') : 'signup-input-item'}>
        // <li className={('signup-input-item', itemClass && 'signup-input-item ' + itemClass)}>
        // <li className={['signup-input-item', itemClass && itemClass].filter(c => c).join(' ')}>
        <li className={['signup-input-item', itemClass && itemClass].join(' ').trim()}>
            {convert ? children : <input type={type} value={value} onChange={handleInputChange} placeholder={placeholder} name={name} {...rest} />}
        </li>
    );
};

const SignUpInputList = ({children}) => {
    return <ul className="signup-input-list">{children}</ul>
};

function SignUpInput({user, selection, onInputChange}) {
    const handleInputChange = (e) => {
        const { value, name } = e.target;
        onInputChange({ value, name });
    }
    return (
    <SignUpInputList>
        <SignUpInputItem type="email" value={user.email} onInputChange={onInputChange} placeholder="Email" name="email" required />
        <SignUpInputItem convert itemClass="input-password">
            <input type="password" value={user.password1} onChange={handleInputChange} placeholder="Password" name="password" required />
            <input type="password" value={user.password2} onChange={handleInputChange} placeholder="Repeat Password" name="repassword" required />
        </SignUpInputItem>
        <SignUpInputItem type="text" value={user.name} onInputChange={onInputChange} placeholder="Name" name="name" required />
        <SignUpInputItem convert itemClass="input-phone">
            <select name="countryCode" value={user.countryCode} onChange={handleInputChange}>
                {Object.keys(selection.countryCode).map((key, index) => 
                <option key={index} value={selection.countryCode[key]}> {key.firstCapitalize()} (+{selection.countryCode[key]}) </option>)}
            </select>
            <input type="tel" value={user.phone} onChange={handleInputChange} placeholder="Phone" name="phone" />
        </SignUpInputItem>
        <SignUpInputItem type="date" value={user.birth} onInputChange={onInputChange} placeholder="Birth" name="birth" />
        <SignUpInputItem convert>
            <select name="sex" value={user.sex} onChange={handleInputChange}>
                <option value="" disabled hidden>Sex</option>
                {/* {Object.keys(selection.sex).map((key) => 
                <option key={key} value={key}> {selection.sex[key]} </option>)} */}
                {selection.sex.map((item, index) => 
                <option key={index} value={index+1}> {item} </option>)}
            </select>
        </SignUpInputItem>
    </SignUpInputList>
    );
};

export default SignUpInput;