import React, { Fragment } from 'react';
import { Link } from 'react-router-dom';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'

function SignUpAccept({validation, onValidChange}) {
    const handleValidChange = (e) => onValidChange({ value: !validation.terms, name: e.target.name });
    return (
        <Fragment>
            <div className="checkbox">
                <input className="checkbox-hidden" type="checkbox" name="terms" value={validation.terms} onChange={handleValidChange}/>
                <span className="checkbox-shape">
                    {validation.terms && <FontAwesomeIcon className="fa-ico" icon="check" size="sm"/>}
                </span>
            </div>
            <span>Please accept the terms <Link to="">Terms &amp; Privacy</Link></span>
        </Fragment>
    );
};

export default SignUpAccept;