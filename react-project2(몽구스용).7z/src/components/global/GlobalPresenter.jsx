import React from 'react'
import styled from 'styled-components'
import GlobalHeader from './header/GlobalHeader'
import Main from './main/Main'

const GlobalWarpper = styled.div`
`;

export default function GlobalPresenter({children}) {
  return (
    <GlobalWarpper id="global-wrapper">
        <GlobalHeader />
        <Main children={children} />
    </GlobalWarpper>
  )
}
