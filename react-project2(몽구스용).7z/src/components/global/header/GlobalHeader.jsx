import React, { Component } from 'react';
import NavbarContainer from 'containers/widget/navbar/NavbarContainer'
import ToolbarContainer from 'containers/widget/toolbar/ToolbarContainer'
import styled from 'styled-components'

const GlobalHeaderContainer = styled.header`
    width:100%; height:50px; background: #333; 
        .global-header-inside { width:1300px; height:50px; margin: 0 auto; display: flex; 
            & > * { flex-basis:0; flex-grow:1; }
        }
`;

const GlobalHeaderInside = ({children}) => {
    return (
        <div className="global-header-inside">
            {children}                
        </div>
    )
}

class GlobalHeader extends Component {
    render() {
        return (
            <GlobalHeaderContainer id="global-header">
                <GlobalHeaderInside>
                    <NavbarContainer/>
                    <ToolbarContainer/>
                </GlobalHeaderInside>
            </GlobalHeaderContainer>
        );
    }
}

export default GlobalHeader;