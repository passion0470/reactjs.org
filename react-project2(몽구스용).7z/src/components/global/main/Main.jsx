import React, { Component } from 'react';
import MainContent from './content/MainContent'
import styled from 'styled-components'
import { TransitionGroup, CSSTransition } from "react-transition-group";
import { withRouter } from 'react-router-dom'

const Wrapper = styled.main`
    background: #fff; width: 1300px; min-height:850px; margin: 0 auto; display: flex; position: relative;
    .is-default-content { width:85%; }
`;

class Main extends Component {
    render() {
        const { location/* , history */ } = this.props
        // console.log(location, history)
        return (
            <Wrapper id="main">
                <TransitionGroup component={null}>
                    <CSSTransition key={location.pathname} timeout={{ enter: 800, exit: 0 }} classNames="fade-page">
                        <MainContent children={this.props.children} />
                    </CSSTransition>
                </TransitionGroup>
            </Wrapper>
        );
    }
}

export default withRouter(Main)