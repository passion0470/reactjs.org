import React from 'react';
import styled from 'styled-components'

const Wrapper = styled.div`
    width:100%;
    header.main-content-header { width:100%; display: flex; padding: 10px 10px; box-sizing: border-box; border-bottom: 1px #f0f0f0 solid;
        & > * { flex-basis:0; flex-grow:1; }
    }
    .main-content-body { width:100%; height:100%; padding: 10px 10px; box-sizing: border-box; }
`;

const MainContent = ({children}) => {
    return (
        // <Wrapper className={location.state && location.state.fadeClass ? ['main-content', 'is-fade-page'].join(' ') : 'main-content'}>
        <Wrapper className='main-content'>
            <header className="main-content-header">
                <h5> 제목영역 </h5>
            </header>
            {children}
            <footer className="main-content-footer"></footer>
        </Wrapper>
    )
}

export default MainContent