import React, { Component } from 'react';
import { HashRouter as Router, Route } from 'react-router-dom'
import authService from 'services/authService'

import GlobalStyles from './styles/common'
import GlobalCotainer from './containers/global/GlobalCotainer'

import { library } from '@fortawesome/fontawesome-svg-core'
import { faSignInAlt, faUserPlus, faPowerOff, faFileContract, faUserCog, faEnvelope, faUser, faCheck } from '@fortawesome/pro-solid-svg-icons'
library.add(faSignInAlt, faUserPlus, faPowerOff, faFileContract, faUserCog, faEnvelope, faUser, faCheck)

/* eslint-disable import/first */
import HomePage from './pages/HomePage'
import Company from './pages/Company'
import CsCenter from './pages/CsCenter'
import Product from './pages/Product'
import User from './pages/User'

// eslint-disable-next-line
String.prototype.firstCapitalize = function() {
  return this.charAt(0).toUpperCase() + this.slice(1);
}

// function firstCapitalize(string) {
//     return string.charAt(0).toUpperCase() + string.slice(1);
// }

class App extends Component {
  constructor(){
    super();
    this.authService = new authService();
  }

  componentDidMount() {
    this.handelRefreshIn()
  }

  handelRefreshIn() {
    if(this.authService.refreshedIn() === true) 
      this.authService.refreshIn().then(() => { this.authService.refreshPolling() })
  }

  render() {
    return (
      <Router>
        <GlobalStyles/>
        <GlobalCotainer> 
          <Route exact path='/' component={HomePage}/>
          <Route path='/company' component={Company}/>
          <Route path='/cscenter' component={CsCenter}/>
          <Route path='/product' component={Product}/>
          <Route path='/user' component={User}/>
        </GlobalCotainer>
      </Router>
    );
  }
}

export default App;
