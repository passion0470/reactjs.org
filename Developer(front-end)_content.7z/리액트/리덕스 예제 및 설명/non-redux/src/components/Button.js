import React, { Component } from 'react';
 
class Button extends Component {
    constructor(props) {
        super(props);
        this.onIncrement = this.onIncrement.bind(this);
        this.onDecrement = this.onDecrement.bind(this);
    }
 
    // + 버튼을 클릭 할 경우 실행 되는 이벤트 핸들러. 부모 컴포넌트의 onIncrement 함수를 실행
    onIncrement(event) { this.props.onIncrement(); }
    // - 버튼을 클릭 할 경우 실행 되는 이벤트 핸들러. 부모 컴포넌트의 onDecrement 함수를 실행
    onDecrement(event) { this.props.onDecrement(); }
 
    render() {
        return (
            <div>
                {/* 이벤트 핸들러 등록 */}
                <button onClick={this.onIncrement}>+</button>
                <button onClick={this.onDecrement}>-</button>
            </div>
        );
    }
}
 
export default Button;

