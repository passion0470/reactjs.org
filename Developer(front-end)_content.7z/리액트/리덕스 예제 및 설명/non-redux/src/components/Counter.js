import React, { Component } from 'react';
 
class Counter extends Component {
    render() {
        return (
            <div>
                {/* 전달 받은 value를 출력 */}
                <h1>Value : {this.props.value}</h1>
            </div>
        );
    }
}
 
export default Counter;

