import React, { Component } from 'react';
// 사용할 컴포넌트를 import
import Counter from './Counter';
import Option from './Option';
import Button from './Button';
 
class App extends Component {
    constructor(props) {
        super(props);
        this.state = { value: 0, diff: 1 };
        this.onChange = this.onChange.bind(this);
        this.onIncrement = this.onIncrement.bind(this);
        this.onDecrement = this.onDecrement.bind(this);
    }
    // Option에서 실행되는 이벤트 핸들러. 사용자의 입력 값을 state.diff에 저장.
    onChange(diff) {
        this.setState({ diff: diff });
    }
    // Button에서 실행되는 이벤트 핸들러. state.diff와 이전의 state, 즉 prevState.value를 합친 값을 state.value에 저장
    onIncrement() {
        this.setState(prevState => ({
        value: prevState.value + Number(this.state.diff)
        }));
    }
    // Button에서 실행되는 이벤트 핸들러. state.diff에 preState.value를 뺀 값을 state.value에 저장
    onDecrement() {
        this.setState(prevState => ({
        value: prevState.value - Number(this.state.diff)
        }));
    }
    
    render() {
        return (
        <div style={{textAlign: 'center'}}>
            {/* Counter 컴포넌트를 불러옴. state.value를 출력 할 수 있도록 value attribute를 선언 */}
            <Counter value={this.state.value} />
            {/* Option 컴포넌트를 불러옴. state.diff를 보여주기 위해 diff attrubute를 선언하고, 변화된 값을 state에 저장하기 위해 onChange 이벤트 핸들러를 등록 */}
            <Option diff={this.state.diff} onChange={this.onChange} />
            {/* Button 컴포넌트를 불러옴. Button 컴포넌트에서 실행되는 이벤트 핸들러를 핸들링 하기 위해 onIncrement와 onDecrement 이벤트 핸들러를 등록 */}
            <Button onIncrement={this.onIncrement} onDecrement={this.onDecrement} />
        </div>
        );
    }
}
 
export default App;

