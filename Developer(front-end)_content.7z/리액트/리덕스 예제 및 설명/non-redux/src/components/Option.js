import React, { Component } from 'react';
 
class Option extends Component {
    constructor(props) {
        super(props);
        this.onChange = this.onChange.bind(this);
    }
 
    // 사용자가 값 입력시, 입력 값을 부모 컴포넌트로 전달
    onChange(event) {
        this.props.onChange(event.target.value);
    }
 
    render() {
        return (
            <div>
                {/* 부모 컴포넌트로 부터 전달 받은 diff 값을 출력 및 이벤트 핸들러 등록 */}
                <input value={this.props.diff} onChange={this.onChange} />
            </div>
        );
    }
}
 
export default Option;
