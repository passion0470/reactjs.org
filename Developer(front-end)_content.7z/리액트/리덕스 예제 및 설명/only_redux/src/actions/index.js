// action의 type을 정의하여 export
export const INCREMENT = 'INCREMENT';
export const DECREMENT = 'DECREMENT';
export const SET_DIFF = 'SET_DIFF';

// increment action을 정의
export function increment() {
    return {
        type: INCREMENT
    };
}
// decrement action을 정의
export function decrement() {
    return {
        type: DECREMENT
    };
}
// seDiff action을 정의. 어떤 값을 계산(더할지, 뺄지) 해 줄 것인지를 diff에 저장. 나중에는 reducer에 의해 store에 저장.
export function setDiff(value) {
    return {
        type: SET_DIFF,
        diff: value
    };
}

/*
action은 어떤 변화가 일어나야 할지 알려주는 객체. action을 작성 할 때, 첫번째 필드 type은 필수적으로 포함되야 한다. 
type은 action이 무엇을 해야 하는지.. ID와 같은 개념으로 사용된다. 그 이후의 필드는 개발자가 임의로 추가할 수 있다. 
increment와 decrement에는 type만 있지만, setDiff에는 diff 라는 필드가 추가되어 있는 것을 확인 할 수 있다. 
나중에 설명 할 reducer에서 diff를 store에 저장하게 된다.
*/