import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';
import App from './components/App';
import * as serviceWorker from './serviceWorker';
const appElement = document.getElementById('root');

// createStore을 import
import { createStore } from 'redux';
// reducer인 counterApp을 import
import counterApp from './reducers';

// store을 만드는 방법. createStore 메소드를 이용하면 되는데, createStore의 인자로 reducer를 전달해준다. 
const store = createStore(counterApp);

const render = () => {
    ReactDOM.render(
      <App store={store} />,
      appElement
    );
}
// store.subscribe(LISTENER) 형태. dispatch 메소드가 실행되면 (Button 컴포넌트 또는 Option 컴포넌트에서 dispatch 메소드가 실행 되면) LISTENER 함수가 실행. 
// 그렇기 때문에, 데이터가 변경 될 때 마다 다시 랜더링.
store.subscribe(render);
render();
  
// If you want your app to work offline and load faster, you can change
// unregister() to register() below. Note this comes with some pitfalls.
// Learn more about service workers: http://bit.ly/CRA-PWA
serviceWorker.unregister();
