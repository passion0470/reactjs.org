// action에서 정의한 action의 type 들을 import
import { INCREMENT, DECREMENT, SET_DIFF } from '../actions';
// combineReducers 를 import. combineReducers는 reducer가 여러개 있다면, 하나로 합쳐주는 메소드
import { combineReducers } from 'redux';

// state의 초기값을 정의
const counterInitialState = {
    value: 0, diff: 1
};
// counter의 reducer, default parameter을 이용하여 state가 undefined로 넘어 올 경우 초기 state를 설정
const counter = (state = counterInitialState, action) => {
    // action.type에 따라 reducer가 동작하는 부분
    switch(action.type) {
        case INCREMENT:
            // state를 변경시키지 않고, Object.assign 메소드를 통해 state를 복사하여, 복사한 객체를 수정하여 리턴. Redux에서 state는 읽기 전용.
            // return Object.assign({}, state, { value: state.value + state.diff });
            return {...state, value: state.value + state.diff}; //전개연산자로 간략화
        case DECREMENT:
            // return Object.assign({}, state, { value: state.value - state.diff });
            return {...state, value: state.value - state.diff};
        case SET_DIFF:
            // return Object.assign({}, state, { diff: action.diff});
            return {...state, diff: action.diff};
        default:
            return state;
    }
}

// 작성한 reducer을 하나로 합쳐줌
// 첫번째는 리듀셔가 한개일 경우, 두번째는 2개, 세번쨰는 KEY값 부여할 경우
const counterApp = combineReducers({ counter });
// const counterApp = combineReducers({ counter, etc });
// const counterApp = combineReducers({ a: counter, b: etc });

// reducer을 export
export default counterApp;

