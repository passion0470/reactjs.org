import React, { Component } from 'react';
// 보여줄 컴포넌트를 import
import Counter from './Counter';
import Option from './Option';
import Button from './Button';
 
class App extends Component {
  render() {
    return (
      <div style={{textAlign: 'center'}}>
        {/* 각각의 컴포넌트는 모두 store을 사용하기 때문에 store을 전달 */}
        <Counter store={this.props.store} />
        <Option store={this.props.store} />
        <Button store={this.props.store} />
      </div>
    );
  }
}
 
export default App;
