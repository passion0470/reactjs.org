import React, { Component } from 'react';
 
class Counter extends Component {
    render() {
        return (
            <div>
                {/* store.getState()로 store에 저장된 state를 가져와, counter.value를 출력 */}
                <h1>Value : {this.props.store.getState().counter.value}</h1>
            </div>
        );
    }
}
 
export default Counter;

/*
store의 state 구조는 아래와 같습니다.
{ counter: { value: 0, diff: 1 } }
필드명을 가지고, 그 필드명 하위로 state가 구성되어 있는 것을 확인 할 수 있다. 
필드명은 reducer에서 combineReducers 메소드에서 정의한 키와 동일 하다. 
별도의 key를 설정하지 않았다면 reducer의 이름과 동일한 필드명을 가지게 된다.
*/