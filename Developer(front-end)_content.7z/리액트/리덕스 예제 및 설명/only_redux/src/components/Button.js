import React, { Component } from 'react';
// increment와 decrement라는 action을 import (정확히는 action 객체를 리턴하는 함수)
import { increment, decrement } from '../actions';
 
class Button extends Component {
    constructor(props) {
        super(props);
        this.onIncrement = this.onIncrement.bind(this);
        this.onDecrement = this.onDecrement.bind(this);
    }
    // + 버튼을 클릭 했을 때, 실행되는 이벤트 핸들러. 이 이벤트 핸들러는 increment라는 action을 dispatch 한다
    onIncrement(event) { this.props.store.dispatch(increment()) }
    // - 버튼을 클릭 했을 때, 실행되는 이벤트 핸들러. 이 이벤트 핸들러는 decrement라는 action을 dispatch 한다
    onDecrement(event) { this.props.store.dispatch(decrement()) }
 
    render() {
        return (
            <div>
                {/* 이벤트 핸들러 등록 */}
                <button type="button" onClick={this.onIncrement}>+</button>
                <button type="button" onClick={this.onDecrement}>-</button>
            </div>
        );
    }
}
 
export default Button;

