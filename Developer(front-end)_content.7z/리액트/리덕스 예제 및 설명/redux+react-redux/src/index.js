import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';
import App from './components/App';
import * as serviceWorker from './serviceWorker';
const appElement = document.getElementById('root');

// createStore을 import
import { createStore } from 'redux';
//react-redux의 Provider 컴포넌트를 import
import { Provider  } from 'react-redux';
// reducer인 counterApp을 import
import counterApp from './reducers';

// store을 만드는 방법. createStore 메소드를 이용하면 되는데, createStore의 인자로 reducer를 전달해준다. 
const store = createStore(counterApp);

ReactDOM.render(    
    // Provider 컴포넌트 안에 App 컴포넌트를 둠. 그리고 Provider 컴포넌트에만 store을 지정.
    <Provider store={store}>
        <App />
    </Provider>,
    appElement
);

// If you want your app to work offline and load faster, you can change
// unregister() to register() below. Note this comes with some pitfalls.
// Learn more about service workers: http://bit.ly/CRA-PWA
serviceWorker.unregister();
