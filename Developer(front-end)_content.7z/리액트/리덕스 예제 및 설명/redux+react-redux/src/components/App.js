import React, { Component } from 'react';
import Counter from './Counter';
import Option from './Option';
import Button from './Button';
 
class App extends Component {
  render() {
    return (
      <div style={{textAlign: 'center'}}>
        {/* react-redux를 사용 안한 경우와 달리 각각의 컴포넌트에 넘겨주던 store를 넘겨주지 않아도 됨 */}
        <Counter />
        <Option />
        <Button />
      </div>
    );
  }
}
 
export default App;

