import React, { Component } from 'react';
// react-redux의 connect를 import
import { connect } from 'react-redux';
import { increment, decrement } from '../actions';
 
class Button extends Component {
    render() {
        return (
            <div>
                {/* +, - 버튼 클릭시 props.onIncrement, props.onDecrement를 실행. 
                onIncrement, onDecrement를는 mapDispatchToProps에서 정의 */}
                <button type="button" onClick={this.props.onIncrement}>+</button>
                <button type="button" onClick={this.props.onDecrement}>-</button>
            </div>
        );
    }
}
 
let mapDispatchToProps = (dispatch) => {
    return {
        // props.onIncrement를 실행 할 경우 increment action을 dispatch
        onIncrement: () => dispatch(increment()),
        // props.onDecrement를 실행 할 경우 decrement action을 dispatch
        onDecrement: () => dispatch(decrement())
    }
}
// props를 store의 state에 매칭 시켜주는 connect 함수를 실행
Button = connect(undefined, mapDispatchToProps)(Button);
 
export default Button;


