
import React, { Component } from 'react';
// react-redux의 connect를 import
import { connect } from 'react-redux';
import { setDiff } from '../actions';
 
class Option extends Component {
    constructor(props) {
        super(props);
        this.onChange = this.onChange.bind(this);
    }
    // 사용자가 값을 입력할 경우 실행되는 이벤트 핸들러. 이벤트 핸들러는 props.onUpdateDiff 함수를 실행. onUpdateDiff 함수는 code 2의 33번 줄에서 정의
    onChange(event) {
        this.props.onUpdateDiff(parseInt(event.target.value));    
    }
    
    render() {
        return (
            <div>
                {/* props.diff의 값을 출력. diff는 mapStateToProps에서 정의됩니다. */}
                <input value={this.props.diff} onChange={this.onChange} />
            </div>
        );
    }
}

// store.state를 prop로 매핑하는 코드
let mapStateToProps = (state) => {
    return {
        diff: state.counter.diff
    }
}
// props.onUpdateDiff를 실행 할 경우 dispatch할 action을 정의하는 코드
let mapDispatchToProps = (dispatch) =>{
    return {
        onUpdateDiff: (value) => dispatch(setDiff(value))
    };
}
// mapStateToProps와 mapDispatchToProps에서 작성한 내용을 적용하는 connect 메소드를 호출
Option = connect(mapStateToProps, mapDispatchToProps)(Option);
 
export default Option;



